"""Custom desktop window title bar for LORDVAULT Control Center.

Features:
- Premium 46px frameless title bar with near-black charcoal (#080a0d)
- Real PNG logo badge (logo.png) with subtle glow ring
- Crisp two-tone branding: LORD (cyan) VAULT (rose) | Control Center
- Window drag-to-move and double-click maximize/restore
- Subtle workspace status pill with color-coded animated dot & text
- Custom window control buttons with smooth hover animations:
  - Minimize: blue-gray hover
  - Maximize: slate hover
  - Close: vivid red hover fill
- Dual accent lines at bottom (cyan + rose gradient effect)
"""

import os
import re

from PySide6.QtCore import QEasingCurve, QPoint, QPropertyAnimation, QRectF, Qt, Property
from PySide6.QtGui import QColor, QFont, QLinearGradient, QPainter, QPaintEvent, QPen, QPixmap
from PySide6.QtWidgets import (QFrame, QHBoxLayout, QLabel, QPushButton,
                               QSizePolicy, QWidget)

from .theme import ACCENT, BORDER, ERROR, MUTED, SUCCESS, TEXT, WARNING

# Resolve logo path relative to this file
_LOGO_PATH = os.path.join(os.path.dirname(__file__), 'logo.png')


class LordVaultBadge(QWidget):
    """Premium 34x34 logo badge using the real LORDVAULT PNG with a glow ring."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(34, 34)
        self._pixmap = None
        if os.path.isfile(_LOGO_PATH):
            raw = QPixmap(_LOGO_PATH)
            if not raw.isNull():
                self._pixmap = raw.scaled(
                    28, 28,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                )

    def paintEvent(self, event: QPaintEvent):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)

        cx, cy, r = 17.0, 17.0, 16.0

        # Outer glow ring — rose/cyan dual-tone
        glow = QLinearGradient(1, 1, 33, 33)
        glow.setColorAt(0.0, QColor('#38bdf8'))   # cyan top-left
        glow.setColorAt(1.0, QColor('#f43f5e'))   # rose bottom-right
        painter.setPen(QPen(glow, 1.5))
        painter.setBrush(QColor('#0d0f14'))
        painter.drawEllipse(QRectF(1.0, 1.0, 32.0, 32.0))

        # Inner fill circle
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor('#0d0f14'))
        painter.drawEllipse(QRectF(2.5, 2.5, 29.0, 29.0))

        # Draw logo pixmap centred
        if self._pixmap:
            px_w = self._pixmap.width()
            px_h = self._pixmap.height()
            offset_x = int((34 - px_w) / 2)
            offset_y = int((34 - px_h) / 2)
            painter.drawPixmap(offset_x, offset_y, self._pixmap)
        else:
            # Fallback: bold 'L' monogram
            painter.setFont(QFont('Segoe UI', 13, QFont.Weight.Bold))
            painter.setPen(QColor('#38bdf8'))
            painter.drawText(QRectF(0, 0, 34, 34), Qt.AlignmentFlag.AlignCenter, 'L')

        painter.end()


class LordVaultWindowButton(QPushButton):
    """Custom styled window control button with smooth hover animation."""

    _COLORS = {
        'minimize': ('#3b5cc7', '#60a5fa'),   # blue-gray bg, icon on hover
        'maximize': ('#2a3344', '#94a3b8'),   # slate bg, icon on hover
        'close':    ('#c0392b', '#ffffff'),   # vivid red bg, white icon
    }

    def __init__(self, btn_type: str, icon_text: str, tooltip: str = '', parent=None):
        super().__init__(parent)
        self.btn_type = btn_type
        self.icon_text = icon_text
        self.setText(icon_text)
        if tooltip:
            self.setToolTip(tooltip)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setObjectName(f'win_btn_{btn_type}')
        self.setFixedHeight(46)
        self.setFixedWidth(52 if btn_type == 'close' else 46)

        self._hover = 0.0
        self.motion = True
        self.anim = QPropertyAnimation(self, b'hover', self)
        self.anim.setDuration(130)
        self.anim.setEasingCurve(QEasingCurve.Type.OutCubic)

    @Property(float)
    def hover(self):
        return self._hover

    @hover.setter
    def hover(self, val):
        self._hover = val
        self.update()

    def set_icon_text(self, text: str):
        self.icon_text = text
        self.setText(text)
        self.update()

    def enterEvent(self, event):
        self.anim.stop()
        if self.motion:
            self.anim.setStartValue(self._hover)
            self.anim.setEndValue(1.0)
            self.anim.start()
        else:
            self.hover = 1.0
        super().enterEvent(event)

    def leaveEvent(self, event):
        self.anim.stop()
        if self.motion:
            self.anim.setStartValue(self._hover)
            self.anim.setEndValue(0.0)
            self.anim.start()
        else:
            self.hover = 0.0
        super().leaveEvent(event)

    def paintEvent(self, event: QPaintEvent):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        bg_hex, icon_hover_hex = self._COLORS.get(self.btn_type, ('#1c2028', '#ffffff'))

        # Hover fill
        if self._hover > 0.005:
            bg = QColor(bg_hex)
            bg.setAlpha(int(220 * self._hover))
            painter.fillRect(self.rect(), bg)

        # Icon color: dim when idle, bright on hover
        idle_color = QColor('#52606e')
        active_color = QColor(icon_hover_hex)
        r = idle_color.red()   + int((active_color.red()   - idle_color.red())   * self._hover)
        g = idle_color.green() + int((active_color.green() - idle_color.green()) * self._hover)
        b = idle_color.blue()  + int((active_color.blue()  - idle_color.blue())  * self._hover)
        text_color = QColor(r, g, b)

        painter.setPen(text_color)
        if self.btn_type == 'minimize':
            painter.setFont(QFont('Segoe UI', 14, QFont.Weight.Normal))
            painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, '—')
        elif self.btn_type == 'maximize':
            painter.setFont(QFont('Segoe UI Symbol', 10, QFont.Weight.Normal))
            painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, self.icon_text)
        else:  # close
            painter.setFont(QFont('Segoe UI', 12, QFont.Weight.Medium))
            painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, '✕')
        painter.end()


class StateLabel(QLabel):
    """Status label that mirrors its color to an associated indicator dot."""

    def __init__(self, text: str = '', parent=None):
        super().__init__(text, parent)
        self.dot_label = None

    def setText(self, text: str):
        clean = re.sub(r'^[●\s]+', '', text)
        super().setText(clean)

    def setStyleSheet(self, style: str):
        super().setStyleSheet(style)
        if self.dot_label:
            match = re.search(r'color:\s*([^;]+)', style)
            if match:
                color = match.group(1).strip()
                self.dot_label.setStyleSheet(f'color: {color}; font-size: 8px;')


class LordVaultTitleBar(QFrame):
    """Premium 46px frameless title bar with real PNG logo, two-tone brand, status pill."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName('titleBar')
        self.setFixedHeight(46)
        self.setStyleSheet('''
            QFrame#titleBar {
                background: #080a0d;
                border-bottom: 1px solid #141720;
            }
        ''')
        self._drag_pos = None

        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 0, 0, 0)
        layout.setSpacing(0)

        # ── 1. Logo badge ────────────────────────────────────────────────────
        self.badge = LordVaultBadge()
        layout.addWidget(self.badge)
        layout.addSpacing(10)

        # ── 2. Thin vertical accent line (cyan | rose gradient) ───────────
        self._accent_sep = _GradientSep()
        layout.addWidget(self._accent_sep)
        layout.addSpacing(10)

        # ── 3. Two-tone brand: LORD (cyan) VAULT (rose) │ Control Center ──
        self.brand_title = QLabel()
        self.brand_title.setText(
            '<span style="font-family: Segoe UI; font-weight: 800; color: #38bdf8;'
            ' letter-spacing: 2px; font-size: 12px;">LORD</span>'
            '<span style="font-family: Segoe UI; font-weight: 800; color: #f43f5e;'
            ' letter-spacing: 2px; font-size: 12px;">VAULT</span>'
            '<span style="font-family: Segoe UI; color: #2d3340; font-size: 12px;">'
            '&nbsp;&nbsp;│&nbsp;&nbsp;</span>'
            '<span style="font-family: Segoe UI; font-weight: 400; color: #6b7685;'
            ' font-size: 10px; letter-spacing: 1px;">Control Center</span>'
        )
        self.brand_title.setTextFormat(Qt.TextFormat.RichText)
        self.brand_title.setAlignment(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft)
        layout.addWidget(self.brand_title)

        # ── 4. Draggable spacer ──────────────────────────────────────────────
        layout.addStretch(1)

        # ── 5. Status pill ───────────────────────────────────────────────────
        self.status_pill = QFrame()
        self.status_pill.setObjectName('statusPill')
        self.status_pill.setStyleSheet('''
            QFrame#statusPill {
                background: #0e1117;
                border: 1px solid #1e2530;
                border-radius: 5px;
            }
        ''')
        pill_layout = QHBoxLayout(self.status_pill)
        pill_layout.setContentsMargins(10, 3, 10, 3)
        pill_layout.setSpacing(6)

        self.dot = QLabel('●')
        self.dot.setStyleSheet('font-size: 7px; color: #52606e;')
        pill_layout.addWidget(self.dot)

        self.state = StateLabel('WORKSPACE IDLE')
        self.state.dot_label = self.dot
        self.state.setStyleSheet(
            'color: #52606e; font-size: 9px; font-weight: 600;'
            ' letter-spacing: 1.5px; font-family: Segoe UI;'
        )
        pill_layout.addWidget(self.state)

        layout.addWidget(self.status_pill)
        layout.addSpacing(10)

        # ── 6. Divider ───────────────────────────────────────────────────────
        div = QFrame()
        div.setFixedSize(1, 18)
        div.setStyleSheet('background: #1e2530;')
        layout.addWidget(div)

        # ── 7. Window control buttons ────────────────────────────────────────
        btn_box = QHBoxLayout()
        btn_box.setContentsMargins(0, 0, 0, 0)
        btn_box.setSpacing(0)

        self.min_btn   = LordVaultWindowButton('minimize', '—',  tooltip='Minimize')
        self.max_btn   = LordVaultWindowButton('maximize', '□',  tooltip='Maximize')
        self.close_btn = LordVaultWindowButton('close',    '✕',  tooltip='Close')

        self.min_btn.clicked.connect(self._on_minimize)
        self.max_btn.clicked.connect(self._on_toggle_maximize)
        self.close_btn.clicked.connect(self._on_close)

        btn_box.addWidget(self.min_btn)
        btn_box.addWidget(self.max_btn)
        btn_box.addWidget(self.close_btn)
        layout.addLayout(btn_box)

    # ── Bottom dual accent line ─────────────────────────────────────────────
    def paintEvent(self, event):
        super().paintEvent(event)
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        w = self.width()
        h = self.height()
        # Dual-tone bottom border: cyan left half → rose right half
        grad = QLinearGradient(0, h - 1, w, h - 1)
        grad.setColorAt(0.0,  QColor('#38bdf8'))
        grad.setColorAt(0.45, QColor('#38bdf8'))
        grad.setColorAt(0.55, QColor('#f43f5e'))
        grad.setColorAt(1.0,  QColor('#f43f5e'))
        painter.setPen(QPen(grad, 1.5))
        painter.drawLine(0, h - 1, w, h - 1)
        painter.end()

    # ── Public API ──────────────────────────────────────────────────────────
    def set_motion(self, enabled: bool):
        self.min_btn.motion   = enabled
        self.max_btn.motion   = enabled
        self.close_btn.motion = enabled

    def update_maximize_icon(self, is_maximized: bool):
        if is_maximized:
            self.max_btn.set_icon_text('❐')
            self.max_btn.setToolTip('Restore')
        else:
            self.max_btn.set_icon_text('□')
            self.max_btn.setToolTip('Maximize')

    def set_status(self, text: str, color: str = '#52606e'):
        clean = text.replace('●', '').strip()
        self.state.setText(clean)
        self.state.setStyleSheet(
            f'color: {color}; font-size: 9px; font-weight: 600;'
            f' letter-spacing: 1.5px; font-family: Segoe UI;'
        )
        self.dot.setStyleSheet(f'font-size: 7px; color: {color};')

    # ── Internal window control ─────────────────────────────────────────────
    def _on_minimize(self):
        window = self.window()
        if window:
            window.showMinimized()

    def _on_toggle_maximize(self):
        window = self.window()
        if not window:
            return
        if window.isMaximized():
            window.showNormal()
            self.update_maximize_icon(False)
        else:
            window.showMaximized()
            self.update_maximize_icon(True)

    def _on_close(self):
        window = self.window()
        if window:
            window.close()

    def mouseDoubleClickEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._on_toggle_maximize()
        super().mouseDoubleClickEvent(event)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            window = self.window()
            if window and window.windowHandle():
                if window.windowHandle().startSystemMove():
                    return
            self._drag_pos = event.globalPosition().toPoint() - self.window().frameGeometry().topLeft()
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._drag_pos and event.buttons() == Qt.MouseButton.LeftButton:
            window = self.window()
            if window:
                if window.isMaximized():
                    window.showNormal()
                    self.update_maximize_icon(False)
                window.move(event.globalPosition().toPoint() - self._drag_pos)
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        self._drag_pos = None
        super().mouseReleaseEvent(event)


class _GradientSep(QWidget):
    """Thin 2px vertical line with cyan→rose gradient — used as a visual accent separator."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(2, 22)

    def paintEvent(self, event):
        painter = QPainter(self)
        grad = QLinearGradient(0, 0, 0, 22)
        grad.setColorAt(0.0, QColor('#38bdf8'))
        grad.setColorAt(1.0, QColor('#f43f5e'))
        painter.fillRect(self.rect(), grad)
        painter.end()
