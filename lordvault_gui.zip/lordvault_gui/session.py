"""Desktop transport for the existing launcher, with no backend substitutions.

The launcher runs in its own process. Its stdin is a pipe, selecting its existing
line-input fallback; every answer is sent verbatim followed by one newline.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import threading

from PySide6.QtCore import QObject, Signal, Slot


class _AnsiDecoder:
    """Remove terminal escapes even when a stream read splits an escape."""

    def __init__(self):
        self.pending = ""

    def feed(self, text: str) -> str:
        text = self.pending + text
        self.pending = ""
        result = []
        position = 0
        while position < len(text):
            if text[position] != "\x1b":
                char = text[position]
                if char in "\n\r\t" or ord(char) >= 32:
                    result.append(char)
                position += 1
                continue
            start = position
            position += 1
            if position >= len(text):
                self.pending = text[start:]
                break
            kind = text[position]
            position += 1
            if kind == "[":
                while position < len(text) and not ("@" <= text[position] <= "~"):
                    position += 1
                if position == len(text):
                    self.pending = text[start:]
                    break
                position += 1
            elif kind == "]":
                match = re.search(r"\x07|\x1b\\", text[position:])
                if not match:
                    self.pending = text[start:]
                    break
                position += match.end()
        return "".join(result)


def _python_executable() -> str:
    executable = Path(sys.executable)
    if executable.name.lower() == "pythonw.exe":
        console = executable.with_name("python.exe")
        if console.exists():
            return str(console)
    return str(executable)


def _hidden_startup():
    if os.name != "nt":
        return None
    startup = subprocess.STARTUPINFO()
    startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    startup.wShowWindow = subprocess.SW_HIDE
    return startup


def _backend_python() -> str:
    """Retain the terminal launcher's Python 3.12 preference on Windows."""
    if sys.version_info[:2] == (3, 12) or os.name != "nt":
        return _python_executable()
    launcher = shutil.which("py")
    if launcher:
        try:
            result = subprocess.run(
                [launcher, "-3.12", "-c", "import sys; print(sys.executable)"],
                capture_output=True, text=True, timeout=5, check=False,
                startupinfo=_hidden_startup(),
                creationflags=subprocess.CREATE_NO_WINDOW,
            )
            path = result.stdout.strip()
            if result.returncode == 0 and Path(path).is_file():
                return path
        except (OSError, subprocess.TimeoutExpired):
            pass
    return _python_executable()


class BackendSession(QObject):
    """One launcher session. Signals are delivered on the owning Qt thread.

    ``output`` contains plain text chunks, including partial lines and carriage
    returns. ``prompt`` is a display hint, never a gate on forwarding input.
    ``command`` is useful for offline transport tests; normal use omits it.
    """

    output = Signal(str)
    prompt = Signal(str)
    state_changed = Signal(str)
    finished = Signal(int)
    error = Signal(str)
    progress = Signal(int, int)
    _record = Signal(int, object)

    def __init__(self, root: Path | str, parent=None, command: list[str] | None = None):
        super().__init__(parent)
        self.root = Path(root).resolve()
        self.command = command
        self._state = "stopped"
        self._process: subprocess.Popen | None = None
        self._lock = threading.RLock()
        self._generation = 0
        self._stop_requested = False
        self._force_requested = False
        self._decoder = _AnsiDecoder()
        self._tail = ""
        self._last_prompt = ""
        self._record.connect(self._receive)

    @property
    def is_running(self) -> bool:
        return self._state != "stopped"

    @property
    def state(self) -> str:
        return self._state

    def _set_state(self, state: str):
        if state != self._state:
            self._state = state
            self.state_changed.emit(state)

    @Slot()
    def start(self):
        if self.is_running:
            return
        self._generation += 1
        self._stop_requested = self._force_requested = False
        self._decoder = _AnsiDecoder()
        self._tail = self._last_prompt = ""
        self.prompt.emit("")
        self._set_state("starting")
        threading.Thread(
            target=self._run, args=(self._generation,), daemon=True,
            name="LordVault-session",
        ).start()

    def _run(self, generation: int):
        code = -1
        process = None
        try:
            command = self.command or [_backend_python(), "-u", str(self.root / "launcher.py")]
            env = os.environ.copy()
            env.update(LORDVAULT_BACKEND="1", PYTHONUNBUFFERED="1", PYTHONIOENCODING="utf-8")
            kwargs = {"startupinfo": _hidden_startup()}
            if os.name == "nt":
                # A private, hidden console lets Ctrl+C reach the backend while
                # leaving the desktop process and the user's terminal alone.
                kwargs["creationflags"] = subprocess.CREATE_NEW_CONSOLE
            with self._lock:
                if self._stop_requested:
                    code = 0
                    return
                process = subprocess.Popen(
                    [_python_executable(), "-u", str(Path(__file__).with_name("_supervisor.py")),
                     json.dumps(command)],
                    cwd=str(self.root), env=env, stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    **kwargs,
                )
                self._process = process
            assert process.stdout is not None
            for raw in iter(process.stdout.readline, b""):
                try:
                    record = json.loads(raw.decode("utf-8"))
                    if not isinstance(record, dict):
                        raise ValueError("Unexpected supervisor record")
                except (ValueError, UnicodeError):
                    record = {"type": "output", "text": raw.decode("utf-8", errors="replace")}
                self._record.emit(generation, record)
            code = process.wait()
        except Exception as exc:
            self._record.emit(generation, {"type": "error", "text": str(exc)})
        finally:
            if process is not None:
                for stream in (process.stdin, process.stdout):
                    if stream:
                        stream.close()
            with self._lock:
                if self._process is process:
                    self._process = None
            self._record.emit(generation, {"type": "supervisor_finished", "code": code})

    def _write(self, record: dict) -> bool:
        with self._lock:
            process = self._process
            if not process or process.poll() is not None or not process.stdin:
                return False
            try:
                process.stdin.write((json.dumps(record, ensure_ascii=True) + "\n").encode("utf-8"))
                process.stdin.flush()
                return True
            except (OSError, ValueError):
                return False

    @Slot(str)
    def send_input(self, text: str) -> bool:
        sent = self._write({"type": "input", "text": text})
        if sent:
            self._tail = self._last_prompt = ""
            self.prompt.emit("")
        return sent

    @Slot()
    def stop(self):
        if not self.is_running:
            return
        with self._lock:
            self._stop_requested = True
        self._set_state("stopping")
        self._write({"type": "stop"})

    @Slot()
    def force_stop(self):
        if not self.is_running:
            return
        with self._lock:
            self._stop_requested = self._force_requested = True
        self._set_state("stopping")
        self._write({"type": "kill"})

    def close(self):
        """Final app teardown: close the pipe and reap the isolated helper."""
        self.force_stop()
        with self._lock:
            process = self._process
        if process is not None:
            try:
                process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                # Its job handle closes on termination, also stopping children.
                process.kill()
                process.wait(timeout=2)

    @Slot(int, object)
    def _receive(self, generation: int, record: dict):
        if generation != self._generation:
            return
        kind = record.get("type")
        if kind == "started":
            if self._state == "starting":
                self._set_state("running")
        elif kind == "output":
            text = self._decoder.feed(record.get("text", ""))
            if text:
                self.output.emit(text)
                self._inspect(text)
        elif kind == "error":
            self.error.emit(record.get("text", "Unknown session error"))
        elif kind == "finished":
            self._backend_exit_code = int(record.get("code", 0))
        elif kind == "supervisor_finished":
            code = getattr(self, "_backend_exit_code", int(record.get("code", -1)))
            if hasattr(self, "_backend_exit_code"):
                del self._backend_exit_code
            self._set_state("stopped")
            self.prompt.emit("")
            self.finished.emit(code)

    def _inspect(self, text: str):
        combined = (self._tail + text)[-16000:]
        for match in re.finditer(r"\b(?:VERIFY|ENROLL)\b[^\r\n]*?(\d+)\s*/\s*(\d+)", combined):
            current, total = map(int, match.groups())
            if total:
                self.progress.emit(current, total)
        self._tail = re.split(r"[\r\n]", combined)[-1][-4000:]
        tail = self._tail.strip()
        is_prompt = (
            tail.endswith(("❯", "›"))
            or ("ASK" in tail and tail.endswith(":"))
            or bool(re.search(r"press\s+(?:enter|return)\b", tail, re.I))
        )
        if is_prompt and tail != self._last_prompt:
            label = re.sub(r"^[\s╰─❯›]+", "", tail)
            label = re.sub(r"[\s→❯›]+$", "", label).strip()
            self._last_prompt = tail
            self.prompt.emit(label or "Press Enter to continue")
