import json
from pathlib import Path

from PySide6.QtCore import Qt, QUrl, Signal
from PySide6.QtGui import QDesktopServices, QFont
from PySide6.QtWidgets import (
    QComboBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

import interface
from .components import LordVaultToggleSwitch
from .theme import (
    ACCENT,
    BG,
    BORDER,
    BORDER_HOVER,
    DISABLED,
    ERROR,
    MUTED,
    PANEL,
    PANEL_HOVER,
    SUCCESS,
    TEXT,
    WARNING,
)

# Vivid accent colors for each section / category
_CYAN   = '#38bdf8'   # sky blue   – tokens / workspace
_PURPLE = '#c084fc'   # violet     – configuration / combo
_PINK   = '#f43f5e'   # rose       – guide / orbs
_AMBER  = '#f59e0b'   # amber gold – token manager
_GREEN  = '#22c55e'   # emerald    – workers / success
_MUTED  = MUTED


def _label(text, role="", *, color=None, mono=False, size=None):
    label = QLabel(str(text))
    label.setTextFormat(Qt.TextFormat.PlainText)
    if role:
        label.setObjectName(role)
    font = QFont("Cascadia Mono" if mono else "Segoe UI")
    if size is not None:
        font.setPointSize(size)
    label.setFont(font)
    if color:
        label.setStyleSheet(f"color: {color};")
    label.setWordWrap(True)
    return label


def _panel(title, accent=_PURPLE):
    panel = QFrame()
    panel.setObjectName("panel")
    layout = QVBoxLayout(panel)
    layout.setContentsMargins(20, 18, 20, 18)
    layout.setSpacing(12)
    layout.addWidget(_label(title, "eyebrow", color=accent, mono=True, size=9))
    return panel, layout


def _setting(layout, label, value="—", color=None):
    row = QHBoxLayout()
    row.setSpacing(20)
    name = _label(label, "muted", color=_MUTED, size=9)
    field = _label(value, "settingValue", color=color, mono=True, size=9)
    field.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
    field.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
    row.addWidget(name, 1)
    row.addWidget(field, 1)
    layout.addLayout(row)
    return field


class _WorkspacePage(QWidget):
    activity = Signal(str, str)

    def __init__(self, title, subtitle, parent=None):
        super().__init__(parent)
        self.setObjectName("workspacePage")
        self.setStyleSheet("""
            QWidget#workspacePage { background: transparent; color: #f5f7fa; }
            QWidget#workspacePage QScrollArea { border: none; background: transparent; }
            QWidget#workspacePage QWidget#pageContents { background: transparent; }
            QWidget#workspacePage QFrame#panel {
                background: #111318; border: 1px solid #252a32; border-radius: 8px;
            }
            QWidget#workspacePage QLabel { background: transparent; border: none; }
            QWidget#workspacePage QLabel#pageTitle {
                color: #f5f7fa; font: 600 20pt 'Segoe UI';
            }
            QWidget#workspacePage QLabel#muted { color: #8f98a8; }
            QWidget#workspacePage QLabel#settingValue { color: #f5f7fa; }
            QWidget#workspacePage QPushButton {
                background: #15181e; color: #f5f7fa;
                border: 1px solid #252a32; border-radius: 6px;
                padding: 7px 14px; font: 9pt 'Segoe UI'; font-weight: 500;
            }
            QWidget#workspacePage QPushButton:hover {
                background: #1d212a; border-color: #383f4c; color: #ffffff;
            }
            QWidget#workspacePage QPushButton:pressed { background: #111318; border-color: #5b8cff; }
            QWidget#workspacePage QPushButton:focus { border: 1px solid #5b8cff; }
            QWidget#workspacePage QPushButton:disabled {
                color: #666d78; background: #0e1014; border-color: #1a1d24;
            }
            QWidget#workspacePage QPushButton#primary {
                background: #5b8cff; color: #090a0c; border: 1px solid #5b8cff; font-weight: 600;
            }
            QWidget#workspacePage QPushButton#primary:hover {
                background: #709cff; border-color: #709cff; color: #090a0c;
            }
            QWidget#workspacePage QPushButton#primary:disabled {
                background: #1a2233; color: #42526e; border-color: #202b40;
            }
            QWidget#workspacePage QLineEdit {
                background: #0c0e12; border: 1px solid #252a32; border-radius: 6px;
                padding: 6px 10px; color: #f5f7fa; font: 9pt 'Segoe UI';
            }
            QWidget#workspacePage QLineEdit:focus {
                border-color: #5b8cff; background: #0f1218;
            }
            QWidget#workspacePage QSpinBox {
                background: #0c0e12; border: 1px solid #252a32; border-radius: 6px;
                padding: 5px 8px; color: #f5f7fa; font: 9pt 'Segoe UI';
            }
            QWidget#workspacePage QSpinBox:focus {
                border-color: #5b8cff; background: #0f1218;
            }
        """)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.contents = QWidget()
        self.contents.setObjectName("pageContents")
        self.body = QVBoxLayout(self.contents)
        self.body.setContentsMargins(2, 4, 12, 20)
        self.body.setSpacing(16)
        heading = QHBoxLayout()
        titles = QVBoxLayout()
        titles.setSpacing(6)
        titles.addWidget(_label("LORDVAULT // WORKSPACE", "eyebrow", color=_CYAN, mono=True, size=8))
        titles.addWidget(_label(title, "pageTitle"))
        titles.addWidget(_label(subtitle, "muted", color=_MUTED, size=9))
        heading.addLayout(titles, 1)
        self.refresh_button = self._button("Refresh", self._manual_refresh)
        heading.addWidget(self.refresh_button, 0, Qt.AlignmentFlag.AlignTop)
        self.body.addLayout(heading)
        self.scroll.setWidget(self.contents)
        outer.addWidget(self.scroll)

    @staticmethod
    def _button(text, callback):
        button = QPushButton(text)
        button.setCursor(Qt.CursorShape.PointingHandCursor)
        button.clicked.connect(callback)
        return button

    def _manual_refresh(self):
        self.refresh()
        self.activity.emit("INFO", "Workspace view refreshed from local files.")

    def _open_local(self, relative):
        path = Path(interface.__file__).resolve().parent / relative
        if not path.exists():
            self.activity.emit("WARNING", f"Local path is unavailable: {relative}")
            return
        if QDesktopServices.openUrl(QUrl.fromLocalFile(str(path))):
            self.activity.emit("SYSTEM", f"Opened {relative} in the default desktop application.")
        else:
            self.activity.emit("WARNING", f"The desktop could not open {relative}.")

    def _file_button(self, caption, relative):
        button = self._button(caption, lambda: self._open_local(relative))
        button.setToolTip(relative)
        return button

    def refresh(self, snapshot=None):
        """Reload the existing local data without writing any settings."""


class LordVaultTokenManager(_WorkspacePage):
    """Existing token inventory and format counts; token values stay private."""

    def __init__(self, parent=None):
        super().__init__(
            "Token Manager",
            "Your token library, at a glance. Counts reflect the local workspace.",
            parent,
        )
        cards = QGridLayout()
        cards.setSpacing(14)
        self.counts = {}
        for column, (key, title, accent) in enumerate((
            ("total", "TOTAL TOKENS", _CYAN),
            ("combo", "COMBO FORMAT", _PURPLE),
            ("plain", "PLAIN FORMAT", _GREEN),
            ("orbs",  "ORB TOKENS",   _AMBER),
        )):
            panel, layout = _panel(title, accent)
            count = _label("0", color="#f4f4f5", mono=True, size=24)
            layout.addWidget(count)
            layout.addWidget(_label("LOCAL INVENTORY", "muted", color=_MUTED, mono=True, size=8))
            cards.addWidget(panel, 0, column)
            cards.setColumnStretch(column, 1)
            self.counts[key] = count
        self.body.addLayout(cards)

        panel, layout = _panel("LIBRARY SOURCES", _CYAN)
        self.primary_source = _setting(layout, "Workspace tokens", "input/tokens.txt")
        _setting(layout, "Orb tokens", "orb_claimer/token.txt")
        controls = QHBoxLayout()
        controls.setSpacing(10)
        controls.addWidget(self._file_button("Open token file", "input/tokens.txt"))
        controls.addWidget(self._file_button("Open orb token file", "orb_claimer/token.txt"))
        controls.addStretch()
        layout.addLayout(controls)
        self.body.addWidget(panel)

        formats, layout = _panel("SUPPORTED FORMATS")
        _setting(layout, "Plain", "token", _CYAN)
        _setting(layout, "Combo", "email:password:token", _PURPLE)
        layout.addWidget(_label(
            "One entry per line. Combo entries contain two or more colons; "
            "blank lines are excluded from counts.",
            "muted", color=_MUTED, size=10,
        ))
        layout.addWidget(_label(
            "Token values stay hidden in this view. Validation runs through the existing workspace flow.",
            "muted", color=_MUTED, size=10,
        ))
        self.body.addWidget(formats)
        self.body.addStretch()
        self.refresh()

    def refresh(self, snapshot=None):
        tokens = interface._read_lines("input/tokens.txt")
        combo = sum(1 for token in tokens if token.count(":") >= 2)
        values = {
            "total": len(tokens),
            "combo": combo,
            "plain": len(tokens) - combo,
            "orbs": interface.get_orb_token_count(),
        }
        for key, value in values.items():
            self.counts[key].setText(f"{value:,}")


class LordVaultConfigPage(_WorkspacePage):
    """Interactive desktop configuration editor — all config.json fields, safe save."""


    saved = Signal()

    def __init__(self, parent=None):
        super().__init__(
            "Configuration",
            "Directly configure workspace settings. Changes are saved to input/config.json.",
            parent,
        )
        self.fields = {}
        self._block_changes = False
        self._baseline = {}

        # ── Top Action & Status Bar ──────────────────────────────────────────
        action_bar = QFrame()
        action_bar.setObjectName("panel")
        bar_layout = QHBoxLayout(action_bar)
        bar_layout.setContentsMargins(16, 10, 16, 10)
        bar_layout.setSpacing(12)
        self.status_badge = QLabel("● Synced with config.json")
        self.status_badge.setStyleSheet(f"color: {MUTED}; font-size: 11px; font-weight: 500;")
        bar_layout.addWidget(self.status_badge)
        bar_layout.addStretch()
        self.reload_btn = QPushButton("Reload Config")
        self.reload_btn.setToolTip("Discard unsaved changes and reload from input/config.json")
        self.reload_btn.clicked.connect(self._on_reload)
        bar_layout.addWidget(self.reload_btn)
        self.reset_btn = QPushButton("Reset Changes")
        self.reset_btn.setToolTip("Revert uncommitted edits in this form")
        self.reset_btn.setEnabled(False)
        self.reset_btn.clicked.connect(self._on_reset)
        bar_layout.addWidget(self.reset_btn)
        self.save_btn = QPushButton("Save Changes")
        self.save_btn.setObjectName("primary")
        self.save_btn.setToolTip("Validate and write changes to input/config.json")
        self.save_btn.setEnabled(False)
        self.save_btn.clicked.connect(self._on_save)
        bar_layout.addWidget(self.save_btn)
        self.body.addWidget(action_bar)

        # ── 2-Column Grid ────────────────────────────────────────────────────
        grid = QGridLayout()
        grid.setSpacing(14)
        grid.setColumnStretch(0, 1)
        grid.setColumnStretch(1, 1)

        # ── 1. BOT CREDENTIALS (full width) ─────────────────────────────────
        panel_cred, layout_cred = _panel("BOT CREDENTIALS", _CYAN)
        mask_hdr = QHBoxLayout()
        mask_hdr.addWidget(_label("Sensitive values are masked by default.", "muted", color=_MUTED, size=9))
        mask_hdr.addStretch()
        self.mask_switch = LordVaultToggleSwitch(False)
        mask_hdr.addWidget(_label("Show private values", "muted", color=_MUTED, size=9))
        mask_hdr.addWidget(self.mask_switch)
        layout_cred.addLayout(mask_hdr)

        self.fields["bot_token"] = QLineEdit()
        self.fields["bot_token"].setPlaceholderText("Bot token (MTU...abc)")
        self.fields["bot_token"].setEchoMode(QLineEdit.EchoMode.Password)
        self._add_row(layout_cred, "Bot token", self.fields["bot_token"])

        self.fields["client_id"] = QLineEdit()
        self.fields["client_id"].setPlaceholderText("Application / client ID")
        self._add_row(layout_cred, "Client ID", self.fields["client_id"])

        self.fields["client_secret"] = QLineEdit()
        self.fields["client_secret"].setPlaceholderText("Client secret")
        self.fields["client_secret"].setEchoMode(QLineEdit.EchoMode.Password)
        self._add_row(layout_cred, "Client secret", self.fields["client_secret"])

        self.fields["redirect_uri"] = QLineEdit()
        self.fields["redirect_uri"].setPlaceholderText("http://localhost:8080")
        self._add_row(layout_cred, "Redirect URI", self.fields["redirect_uri"])

        self.mask_switch.toggled.connect(self._on_toggle_mask)
        self.body.addWidget(panel_cred)

        # ── 2. GENERAL ──────────────────────────────────────────────────────
        panel_gen, layout_gen = _panel("GENERAL", _CYAN)
        self.fields["proxy"] = LordVaultToggleSwitch(False)
        self._add_row(layout_gen, "Use proxy", self.fields["proxy"])
        self.fields["debug"] = LordVaultToggleSwitch(False)
        self._add_row(layout_gen, "Debug mode", self.fields["debug"])
        self.fields["workers"] = QSpinBox()
        self.fields["workers"].setRange(1, 100)
        self.fields["workers"].setFixedWidth(80)
        self._add_row(layout_gen, "Max workers", self.fields["workers"])
        layout_gen.addStretch()
        grid.addWidget(panel_gen, 0, 0)

        # ── 3. QUEST COMPLETER ───────────────────────────────────────────────
        panel_qc, layout_qc = _panel("QUEST COMPLETER", _AMBER)
        self.fields["quest"] = LordVaultToggleSwitch(False)
        self._add_row(layout_qc, "Enabled", self.fields["quest"])
        self.fields["enroll"] = LordVaultToggleSwitch(True)
        self._add_row(layout_qc, "Enroll first", self.fields["enroll"])
        self.fields["quest_threads"] = QSpinBox()
        self.fields["quest_threads"].setRange(1, 50)
        self.fields["quest_threads"].setFixedWidth(80)
        self._add_row(layout_qc, "Threads", self.fields["quest_threads"])
        self.fields["quest_ids"] = QLineEdit()
        self.fields["quest_ids"].setPlaceholderText("Quest IDs, comma-separated")
        self._add_row(layout_qc, "Quest IDs", self.fields["quest_ids"])
        layout_qc.addStretch()
        grid.addWidget(panel_qc, 0, 1)

        # ── 4. ORB CLAIMER ───────────────────────────────────────────────────
        panel_oc, layout_oc = _panel("ORB CLAIMER", _PINK)
        self.fields["orb_enabled"] = LordVaultToggleSwitch(False)
        self._add_row(layout_oc, "Enabled", self.fields["orb_enabled"])
        self.fields["orb"] = LordVaultToggleSwitch(True)
        self._add_row(layout_oc, "Auto claim", self.fields["orb"])
        self.fields["orb_threads"] = QSpinBox()
        self.fields["orb_threads"].setRange(1, 20)
        self.fields["orb_threads"].setFixedWidth(80)
        self._add_row(layout_oc, "Threads", self.fields["orb_threads"])
        self.fields["orb_solver"] = QLineEdit()
        self.fields["orb_solver"].setPlaceholderText("nonecap / twocaptcha")
        self.fields["orb_solver"].setFixedWidth(140)
        self._add_row(layout_oc, "Solver", self.fields["orb_solver"])
        self.fields["orb_api_key"] = QLineEdit()
        self.fields["orb_api_key"].setPlaceholderText("API key (nc_live_...)")
        self.fields["orb_api_key"].setEchoMode(QLineEdit.EchoMode.Password)
        self._add_row(layout_oc, "API Key", self.fields["orb_api_key"])
        self.fields["orb_quest_ids"] = QLineEdit()
        self.fields["orb_quest_ids"].setPlaceholderText("Orb quest IDs, comma-separated")
        self._add_row(layout_oc, "Orb quest IDs", self.fields["orb_quest_ids"])
        self.fields["orb_tokens"] = _label("0 tokens ready", "muted", color=_MUTED, size=9)
        self._add_row(layout_oc, "Tokens ready", self.fields["orb_tokens"])
        layout_oc.addStretch()
        grid.addWidget(panel_oc, 1, 0)

        # ── 5. ORBS BUYER ────────────────────────────────────────────────────
        panel_ob, layout_ob = _panel("ORBS BUYER", _GREEN)
        self.fields["buyer"] = LordVaultToggleSwitch(False)
        self._add_row(layout_ob, "Enabled", self.fields["buyer"])
        self.fields["sku"] = QLineEdit()
        self.fields["sku"].setPlaceholderText(interface.DEFAULT_ORBS_BUYER_SKU)
        self._add_row(layout_ob, "Item SKU", self.fields["sku"])
        layout_ob.addWidget(_label("Purchases only after a confirmed Orbs claim.", "muted", color=_MUTED, size=9))
        layout_ob.addStretch()
        grid.addWidget(panel_ob, 1, 1)

        self.body.addLayout(grid)

        # ── 6. SERVER SETUP (full width) ─────────────────────────────────────
        panel_setup, layout_setup = _panel("SERVER SETUP", _PURPLE)

        self.fields["invite"] = QLineEdit()
        self.fields["invite"].setPlaceholderText("https://discord.gg/...")
        self.fields["invite"].setEchoMode(QLineEdit.EchoMode.Password)
        self._add_row(layout_setup, "Invite link", self.fields["invite"])

        self.fields["voice"] = QLineEdit()
        self.fields["voice"].setPlaceholderText("Voice channel ID")
        self.fields["voice"].setEchoMode(QLineEdit.EchoMode.Password)
        self._add_row(layout_setup, "Voice channel", self.fields["voice"])

        self.fields["text"] = QLineEdit()
        self.fields["text"].setPlaceholderText("Text channel ID")
        self.fields["text"].setEchoMode(QLineEdit.EchoMode.Password)
        self._add_row(layout_setup, "Text channel", self.fields["text"])

        self.fields["vc_mute"] = QSpinBox()
        self.fields["vc_mute"].setRange(0, 1)
        self.fields["vc_mute"].setFixedWidth(60)
        self._add_row(layout_setup, "VC mute (0/1)", self.fields["vc_mute"])

        self.fields["vc_video"] = QSpinBox()
        self.fields["vc_video"].setRange(0, 1)
        self.fields["vc_video"].setFixedWidth(60)
        self._add_row(layout_setup, "VC video (0/1)", self.fields["vc_video"])

        self.fields["vc_stream"] = QSpinBox()
        self.fields["vc_stream"].setRange(0, 1)
        self.fields["vc_stream"].setFixedWidth(60)
        self._add_row(layout_setup, "VC stream (0/1)", self.fields["vc_stream"])

        self.fields["chat_delay"] = QSpinBox()
        self.fields["chat_delay"].setRange(0, 120)
        self.fields["chat_delay"].setFixedWidth(80)
        self._add_row(layout_setup, "Chat delay (s)", self.fields["chat_delay"])

        self.fields["smart_chat"] = LordVaultToggleSwitch(True)
        self._add_row(layout_setup, "Smart chat", self.fields["smart_chat"])

        self.fields["react_channel"] = QLineEdit()
        self.fields["react_channel"].setPlaceholderText("Reaction channel ID")
        self.fields["react_channel"].setEchoMode(QLineEdit.EchoMode.Password)
        self._add_row(layout_setup, "Reaction channel", self.fields["react_channel"])

        self.fields["react_emojis"] = QLineEdit()
        self.fields["react_emojis"].setPlaceholderText("emoji1,emoji2,...")
        self._add_row(layout_setup, "React emojis", self.fields["react_emojis"])

        self.fields["react_delay"] = QSpinBox()
        self.fields["react_delay"].setRange(0, 120)
        self.fields["react_delay"].setFixedWidth(80)
        self._add_row(layout_setup, "Reaction delay (s)", self.fields["react_delay"])

        self.body.addWidget(panel_setup)

        # Quick file buttons
        controls = QHBoxLayout()
        controls.setSpacing(10)
        controls.addWidget(self._file_button("Open configuration", "input/config.json"))
        controls.addWidget(self._file_button("Open input folder", "input"))
        controls.addStretch()
        self.body.addLayout(controls)
        self.body.addStretch()

        self._connect_listeners()
        self.refresh()

    def _add_row(self, layout, label_text, widget):
        row = QHBoxLayout()
        row.setContentsMargins(0, 2, 0, 2)
        row.setSpacing(14)
        name = _label(label_text, "muted", color=_MUTED, size=9)
        row.addWidget(name, 1)
        row.addWidget(widget, 0, Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        layout.addLayout(row)
        return widget

    # ── Private value masking ────────────────────────────────────────────────
    def _on_toggle_mask(self, show):
        mode = QLineEdit.EchoMode.Normal if show else QLineEdit.EchoMode.Password
        for key in ("bot_token", "client_secret", "invite", "voice", "text",
                    "react_channel", "orb_api_key"):
            self.fields[key].setEchoMode(mode)

    # ── Change tracking ──────────────────────────────────────────────────────
    def _connect_listeners(self):
        toggles = ("proxy", "debug", "quest", "enroll", "orb", "orb_enabled",
                   "buyer", "smart_chat")
        spinboxes = ("workers", "quest_threads", "orb_threads", "react_delay",
                     "vc_mute", "vc_video", "vc_stream", "chat_delay")
        texts = ("quest_ids", "sku", "invite", "voice", "text", "react_channel",
                 "bot_token", "client_id", "client_secret", "redirect_uri",
                 "orb_solver", "orb_api_key", "orb_quest_ids", "react_emojis")
        for key in toggles:
            self.fields[key].toggled.connect(self._on_change)
        for key in spinboxes:
            self.fields[key].valueChanged.connect(self._on_change)
        for key in texts:
            self.fields[key].textChanged.connect(self._on_change)

    def _get_current_form_data(self):
        return {
            "bot_token":     self.fields["bot_token"].text().strip(),
            "client_id":     self.fields["client_id"].text().strip(),
            "client_secret": self.fields["client_secret"].text().strip(),
            "redirect_uri":  self.fields["redirect_uri"].text().strip(),
            "proxy":         self.fields["proxy"].isChecked(),
            "debug":         self.fields["debug"].isChecked(),
            "workers":       self.fields["workers"].value(),
            "quest":         self.fields["quest"].isChecked(),
            "enroll":        self.fields["enroll"].isChecked(),
            "quest_threads": self.fields["quest_threads"].value(),
            "quest_ids":     self.fields["quest_ids"].text().strip(),
            "orb_enabled":   self.fields["orb_enabled"].isChecked(),
            "orb":           self.fields["orb"].isChecked(),
            "orb_threads":   self.fields["orb_threads"].value(),
            "orb_solver":    self.fields["orb_solver"].text().strip(),
            "orb_api_key":   self.fields["orb_api_key"].text().strip(),
            "orb_quest_ids": self.fields["orb_quest_ids"].text().strip(),
            "buyer":         self.fields["buyer"].isChecked(),
            "sku":           self.fields["sku"].text().strip(),
            "invite":        self.fields["invite"].text().strip(),
            "voice":         self.fields["voice"].text().strip(),
            "text":          self.fields["text"].text().strip(),
            "vc_mute":       self.fields["vc_mute"].value(),
            "vc_video":      self.fields["vc_video"].value(),
            "vc_stream":     self.fields["vc_stream"].value(),
            "chat_delay":    self.fields["chat_delay"].value(),
            "smart_chat":    self.fields["smart_chat"].isChecked(),
            "react_channel": self.fields["react_channel"].text().strip(),
            "react_emojis":  self.fields["react_emojis"].text().strip(),
            "react_delay":   self.fields["react_delay"].value(),
        }

    def _on_change(self, *args):
        if self._block_changes:
            return
        current = self._get_current_form_data()
        dirty = (current != self._baseline)
        self.save_btn.setEnabled(dirty)
        self.reset_btn.setEnabled(dirty)
        if dirty:
            self.status_badge.setText("● Unsaved changes")
            self.status_badge.setStyleSheet(f"color: {WARNING}; font-weight: 600; font-size: 11px;")
        else:
            self.status_badge.setText("● Synced with config.json")
            self.status_badge.setStyleSheet(f"color: {MUTED}; font-size: 11px;")

    def _on_reset(self):
        if not self._baseline:
            return
        self._block_changes = True
        try:
            b = self._baseline
            self.fields["bot_token"].setText(b["bot_token"])
            self.fields["client_id"].setText(b["client_id"])
            self.fields["client_secret"].setText(b["client_secret"])
            self.fields["redirect_uri"].setText(b["redirect_uri"])
            self.fields["proxy"].setChecked(b["proxy"])
            self.fields["debug"].setChecked(b["debug"])
            self.fields["workers"].setValue(b["workers"])
            self.fields["quest"].setChecked(b["quest"])
            self.fields["enroll"].setChecked(b["enroll"])
            self.fields["quest_threads"].setValue(b["quest_threads"])
            self.fields["quest_ids"].setText(b["quest_ids"])
            self.fields["orb_enabled"].setChecked(b["orb_enabled"])
            self.fields["orb"].setChecked(b["orb"])
            self.fields["orb_threads"].setValue(b["orb_threads"])
            self.fields["orb_solver"].setText(b["orb_solver"])
            self.fields["orb_api_key"].setText(b["orb_api_key"])
            self.fields["orb_quest_ids"].setText(b["orb_quest_ids"])
            self.fields["buyer"].setChecked(b["buyer"])
            self.fields["sku"].setText(b["sku"])
            self.fields["invite"].setText(b["invite"])
            self.fields["voice"].setText(b["voice"])
            self.fields["text"].setText(b["text"])
            self.fields["vc_mute"].setValue(b["vc_mute"])
            self.fields["vc_video"].setValue(b["vc_video"])
            self.fields["vc_stream"].setValue(b["vc_stream"])
            self.fields["chat_delay"].setValue(b["chat_delay"])
            self.fields["smart_chat"].setChecked(b["smart_chat"])
            self.fields["react_channel"].setText(b["react_channel"])
            self.fields["react_emojis"].setText(b["react_emojis"])
            self.fields["react_delay"].setValue(b["react_delay"])
        finally:
            self._block_changes = False
        self.save_btn.setEnabled(False)
        self.reset_btn.setEnabled(False)
        self.status_badge.setText("● Changes reverted")
        self.status_badge.setStyleSheet(f"color: {MUTED}; font-size: 11px;")
        self.activity.emit("INFO", "Unsaved changes reverted back to original values.")

    def _on_reload(self):
        self.refresh()
        self.status_badge.setText("● Reloaded from config.json")
        self.status_badge.setStyleSheet(f"color: {ACCENT}; font-size: 11px;")
        self.activity.emit("INFO", "Configuration reloaded from input/config.json.")

    def _on_save(self):
        data = self._get_current_form_data()
        if data["workers"] < 1 or data["workers"] > 100:
            self.status_badge.setText("● Workers must be between 1 and 100")
            self.status_badge.setStyleSheet(f"color: {ERROR}; font-weight: 600; font-size: 11px;")
            self.activity.emit("ERROR", "Max workers must be between 1 and 100.")
            return
        if data["buyer"] and not data["sku"]:
            self.status_badge.setText("● Item SKU is required when buyer is enabled")
            self.status_badge.setStyleSheet(f"color: {ERROR}; font-weight: 600; font-size: 11px;")
            self.activity.emit("ERROR", "Item SKU is required when Orbs Buyer is enabled.")
            return

        config_path = Path(interface.__file__).resolve().parent / "input" / "config.json"
        try:
            if config_path.exists():
                with open(config_path, "r", encoding="utf-8") as f:
                    cfg = json.load(f)
                if not isinstance(cfg, dict):
                    cfg = {}
            else:
                cfg = {}

            # Root credentials and general
            if data["bot_token"]:
                cfg["bot_token"] = data["bot_token"]
            if data["client_id"]:
                cfg["client_id"] = data["client_id"]
            if data["client_secret"]:
                cfg["client_secret"] = data["client_secret"]
            if data["redirect_uri"]:
                cfg["redirect_uri"] = data["redirect_uri"]
            cfg["use_proxy"]    = data["proxy"]
            cfg["debug"]        = data["debug"]
            cfg["max_workers"]  = data["workers"]

            # Quest completer
            qc = cfg.setdefault("quest_completer", {})
            if not isinstance(qc, dict):
                qc = cfg["quest_completer"] = {}
            qc["enabled"]     = data["quest"]
            qc["enroll_first"] = data["enroll"]
            qc["threads"]     = data["quest_threads"]
            qc["quest_ids"]   = [q.strip() for q in data["quest_ids"].replace("\n", ",").split(",") if q.strip()]

            # Orb claimer
            oc = cfg.setdefault("orb_claimer", {})
            if not isinstance(oc, dict):
                oc = cfg["orb_claimer"] = {}
            oc["enabled"]    = data["orb_enabled"]
            oc["auto_claim"] = data["orb"]
            oc["threads"]    = data["orb_threads"]
            if data["orb_solver"]:
                oc["solver"] = data["orb_solver"]
            if data["orb_api_key"]:
                solver_key = oc.get("solver", "nonecap")
                oc[f"{solver_key}_key"] = data["orb_api_key"]
            if data["orb_quest_ids"]:
                oc["quest_ids"] = [q.strip() for q in data["orb_quest_ids"].replace("\n", ",").split(",") if q.strip()]

            # Orbs buyer
            ob = cfg.setdefault("orbs_buyer", {})
            if not isinstance(ob, dict):
                ob = cfg["orbs_buyer"] = {}
            ob["enabled"] = data["buyer"]
            ob["sku_id"]  = data["sku"]
            if "orb_buyer" in cfg and isinstance(cfg["orb_buyer"], dict):
                cfg["orb_buyer"]["enabled"] = data["buyer"]
                cfg["orb_buyer"]["sku_id"]  = data["sku"]

            # Setup
            setup = cfg.setdefault("setup", {})
            if not isinstance(setup, dict):
                setup = cfg["setup"] = {}
            setup["invite"]           = data["invite"]
            setup["voice_channel_id"] = data["voice"]
            setup["text_channel_id"]  = data["text"]
            setup["vc_mute"]          = data["vc_mute"]
            setup["vc_video"]         = data["vc_video"]
            setup["vc_stream"]        = data["vc_stream"]
            setup["chat_delay"]       = data["chat_delay"]
            setup["smart_chat"]       = data["smart_chat"]
            setup["react_channel_id"] = data["react_channel"]
            setup["react_emojis"]     = data["react_emojis"]
            setup["react_delay"]      = data["react_delay"]

            temp_path = config_path.with_suffix(".json.tmp")
            with open(temp_path, "w", encoding="utf-8") as f:
                json.dump(cfg, f, indent=4)
            temp_path.replace(config_path)

            self._baseline = data
            self.save_btn.setEnabled(False)
            self.reset_btn.setEnabled(False)
            self.status_badge.setText("● Configuration saved")
            self.status_badge.setStyleSheet(f"color: {SUCCESS}; font-weight: 600; font-size: 11px;")
            self.activity.emit("SUCCESS", "Configuration successfully saved to input/config.json.")
            self.saved.emit()
        except Exception as exc:
            self.status_badge.setText(f"● Save error: {exc}")
            self.status_badge.setStyleSheet(f"color: {ERROR}; font-weight: 600; font-size: 11px;")
            self.activity.emit("ERROR", f"Could not save configuration: {exc}")

    def refresh(self, snapshot=None):
        self._block_changes = True
        try:
            cfg  = interface.load_config()
            qc   = interface._mapping(cfg.get("quest_completer"))
            orb  = interface._mapping(cfg.get("orb_claimer"))
            buyer = interface._mapping(cfg.get("orbs_buyer") or cfg.get("orb_buyer"))
            setup = interface._mapping(cfg.get("setup"))

            self.fields["bot_token"].setText(str(cfg.get("bot_token") or ""))
            self.fields["client_id"].setText(str(cfg.get("client_id") or ""))
            self.fields["client_secret"].setText(str(cfg.get("client_secret") or ""))
            self.fields["redirect_uri"].setText(str(cfg.get("redirect_uri") or ""))

            self.fields["proxy"].setChecked(bool(cfg.get("use_proxy", False)))
            self.fields["debug"].setChecked(bool(cfg.get("debug", False)))
            self.fields["workers"].setValue(int(cfg.get("max_workers", 10)))

            self.fields["quest"].setChecked(bool(qc.get("enabled", False)))
            self.fields["enroll"].setChecked(bool(qc.get("enroll_first", True)))
            self.fields["quest_threads"].setValue(int(qc.get("threads", 10)))
            qids = qc.get("quest_ids") or []
            self.fields["quest_ids"].setText(", ".join(str(q) for q in qids))

            self.fields["orb_enabled"].setChecked(bool(orb.get("enabled", True)))
            self.fields["orb"].setChecked(bool(orb.get("auto_claim", True)))
            self.fields["orb_threads"].setValue(int(orb.get("threads", 3)))
            self.fields["orb_solver"].setText(str(orb.get("solver") or ""))
            # API key: look for <solver>_key or nonecap_key
            solver_name = orb.get("solver", "nonecap")
            api_key = orb.get(f"{solver_name}_key") or orb.get("nonecap_key") or ""
            self.fields["orb_api_key"].setText(str(api_key))
            orb_qids = orb.get("quest_ids") or []
            self.fields["orb_quest_ids"].setText(", ".join(str(q) for q in orb_qids))
            ready = interface.get_orb_token_count()
            self.fields["orb_tokens"].setText(f"{ready} tokens ready")

            self.fields["buyer"].setChecked(buyer.get("enabled", True) is not False)
            self.fields["sku"].setText(str(buyer.get("sku_id", interface.DEFAULT_ORBS_BUYER_SKU)))

            self.fields["invite"].setText(str(setup.get("invite") or ""))
            self.fields["voice"].setText(str(setup.get("voice_channel_id") or ""))
            self.fields["text"].setText(str(setup.get("text_channel_id") or ""))
            self.fields["vc_mute"].setValue(int(setup.get("vc_mute", 0)))
            self.fields["vc_video"].setValue(int(setup.get("vc_video", 0)))
            self.fields["vc_stream"].setValue(int(setup.get("vc_stream", 0)))
            self.fields["chat_delay"].setValue(int(setup.get("chat_delay", 0)))
            self.fields["smart_chat"].setChecked(bool(setup.get("smart_chat", True)))
            self.fields["react_channel"].setText(str(setup.get("react_channel_id") or ""))
            self.fields["react_emojis"].setText(str(setup.get("react_emojis") or ""))
            self.fields["react_delay"].setValue(int(setup.get("react_delay", 3)))

            self._baseline = self._get_current_form_data()
            self.save_btn.setEnabled(False)
            self.reset_btn.setEnabled(False)
            self.status_badge.setText("● Synced with config.json")
            self.status_badge.setStyleSheet(f"color: {MUTED}; font-size: 11px;")
        finally:
            self._block_changes = False


class LordVaultGuidePage(_WorkspacePage):
    launchRequested = Signal()

    def __init__(self, parent=None):
        super().__init__(
            "Quick Start Guide",
            "Setup and essentials. Your workspace, one command away.",
            parent,
        )
        self.refresh_button.hide()
        for number, title, text, color, button in (
            ("01", "PREPARE YOUR LIBRARY", "Add tokens to input/tokens.txt, one per line.", _CYAN, ("Open token file", "input/tokens.txt")),
            ("02", "REVIEW YOUR CONFIGURATION", "Review input/config.json. Set your invite link and channel IDs, then review your worker, quest and proxy settings.", _PURPLE, ("Open configuration", "input/config.json")),
            ("03", "OPEN YOUR WORKSPACE", "Choose Launch LordVault to start the existing workspace flow.", _PINK, None),
        ):
            panel, layout = _panel(f"{number}  /  {title}", color)
            layout.addWidget(_label(text, color="#d4d4d8", size=10))
            row = QHBoxLayout()
            if button:
                row.addWidget(self._file_button(*button))
            else:
                row.addWidget(self._button("Launch LordVault", lambda: self.launchRequested.emit()))
            row.addStretch()
            layout.addLayout(row)
            self.body.addWidget(panel)

        panel, layout = _panel("ORB SETTINGS", _PINK)
        layout.addWidget(_label(
            "Orbs Buyer runs automatically after a confirmed Orbs claim. "
            "Review orb_buyer.enabled and orb_buyer.sku_id in your configuration.",
            "muted", color=_MUTED, size=9,
        ))
        self.body.addWidget(panel)
        panel, layout = _panel("TOKEN FORMATS", _CYAN)
        _setting(layout, "Plain", "token", _CYAN)
        _setting(layout, "Combo", "email:password:token", _PURPLE)
        self.body.addWidget(panel)
        self.body.addStretch()


class LordVaultOrbClaimerPage(_WorkspacePage):
    """Dedicated Orb Claimer control page with stats, start/stop, and config summary."""

    launchRequested = Signal()
    stopRequested   = Signal()

    def __init__(self, parent=None):
        super().__init__(
            "Orb Claimer",
            "Monitor and control the Orb Claimer. Configure API key and solver in Configuration.",
            parent,
        )
        self._state = "stopped"

        # ── Status bar ────────────────────────────────────────────────────────
        self.status_bar = QFrame()
        self.status_bar.setObjectName("panel")
        sb_layout = QHBoxLayout(self.status_bar)
        sb_layout.setContentsMargins(16, 10, 16, 10)
        sb_layout.setSpacing(12)
        self.status_label = QLabel("\u25cf IDLE")
        self.status_label.setStyleSheet(f"color: {MUTED}; font-size: 11px; font-weight: 600;")
        sb_layout.addWidget(self.status_label)
        sb_layout.addStretch()
        self.body.addWidget(self.status_bar)

        # ── Stats row ─────────────────────────────────────────────────────────
        stats_row = QHBoxLayout()
        stats_row.setSpacing(14)

        def _stat_card(title, key):
            card = QFrame()
            card.setObjectName("panel")
            card.setStyleSheet(f"QFrame#panel {{ border-left: 3px solid {_PINK}; }}")
            cl = QVBoxLayout(card)
            cl.setContentsMargins(14, 12, 14, 12)
            cl.setSpacing(4)
            lbl_title = QLabel(title.upper())
            lbl_title.setStyleSheet(f"color: {_PINK}; font-size: 8px; font-weight: 700; letter-spacing: 1.5px;")
            cl.addWidget(lbl_title)
            lbl_val = QLabel("—")
            lbl_val.setStyleSheet("color: #f4f4f5; font-size: 18px; font-weight: 700;")
            cl.addWidget(lbl_val)
            return card, lbl_val

        card_tokens, self._lbl_tokens   = _stat_card("Tokens ready",  "tokens")
        card_threads, self._lbl_threads = _stat_card("Threads",        "threads")
        card_solver,  self._lbl_solver  = _stat_card("Solver",         "solver")
        stats_row.addWidget(card_tokens)
        stats_row.addWidget(card_threads)
        stats_row.addWidget(card_solver)
        self.body.addLayout(stats_row)

        # ── Action buttons ────────────────────────────────────────────────────
        btn_panel = QFrame()
        btn_panel.setObjectName("panel")
        btn_layout = QHBoxLayout(btn_panel)
        btn_layout.setContentsMargins(16, 14, 16, 14)
        btn_layout.setSpacing(12)

        self.start_btn = QPushButton("Start Orb Claimer")
        self.start_btn.setObjectName("primary")
        self.start_btn.setStyleSheet(
            "QPushButton#primary {"
            f"  background: {_PINK};"
            "  color: #fff; font-weight: 700; font-size: 12px;"
            "  padding: 10px 28px; border-radius: 6px;"
            "}"
            "QPushButton#primary:hover { background: #fb6b80; }"
            "QPushButton#primary:disabled { background: #3a1520; color: #6b7280; }"
        )
        self.start_btn.setFixedHeight(44)
        self.start_btn.clicked.connect(self._on_start)
        btn_layout.addWidget(self.start_btn)

        self.stop_btn = QPushButton("Stop")
        self.stop_btn.setObjectName("danger")
        self.stop_btn.setEnabled(False)
        self.stop_btn.setFixedHeight(44)
        self.stop_btn.clicked.connect(self._on_stop)
        btn_layout.addWidget(self.stop_btn)

        btn_layout.addStretch()
        self.body.addWidget(btn_panel)

        # ── Config summary card ───────────────────────────────────────────────
        panel_cfg, layout_cfg = _panel("CURRENT CONFIG", _PINK)
        layout_cfg.addWidget(
            _label("Loaded from input/config.json", "muted", color=_MUTED, size=9)
        )
        self._cfg_labels = {}
        for field_name, display in [
            ("orb_enabled",   "Enabled"),
            ("auto_claim",    "Auto claim"),
            ("threads",       "Threads"),
            ("solver",        "Solver"),
            ("api_key",       "API Key"),
            ("orb_quest_ids", "Quest IDs"),
        ]:
            row = QHBoxLayout()
            row.setSpacing(12)
            row.addWidget(_label(display, "muted", color=_MUTED, size=9), 1)
            val_lbl = QLabel("—")
            val_lbl.setStyleSheet("color: #c0c8d4; font-size: 9px;")
            row.addWidget(val_lbl)
            layout_cfg.addLayout(row)
            self._cfg_labels[field_name] = val_lbl

        self.body.addWidget(panel_cfg)
        self.body.addStretch()

        self.refresh()

    # ── Public API ────────────────────────────────────────────────────────────
    def set_state(self, state: str):
        """Called by LordVaultApp.handle_state to update running indicator."""
        self._state = state
        running = state in ("starting", "running")
        self.start_btn.setEnabled(not running)
        self.stop_btn.setEnabled(running)
        colors = {
            "starting": ("#d6a84b", "STARTING"),
            "running":  ("#22c55e", "RUNNING"),
            "stopping": ("#d6a84b", "STOPPING"),
            "stopped":  (MUTED,     "IDLE"),
        }
        color, label = colors.get(state, (MUTED, state.upper()))
        self.status_label.setText(f"\u25cf {label}")
        self.status_label.setStyleSheet(
            f"color: {color}; font-size: 11px; font-weight: 600;"
        )

    def refresh(self, snapshot=None):
        """Reload orb claimer config and update the stats / summary cards."""
        try:
            cfg = interface.load_config()
            orb = interface._mapping(cfg.get("orb_claimer"))

            threads   = int(orb.get("threads", 3))
            solver    = str(orb.get("solver") or "—")
            solver_name = orb.get("solver", "nonecap")
            raw_key   = orb.get(f"{solver_name}_key") or orb.get("nonecap_key") or ""
            api_key   = ("*" * 8 + raw_key[-4:]) if len(raw_key) > 4 else ("—" if not raw_key else raw_key)
            orb_qids  = orb.get("quest_ids") or []
            tokens    = interface.get_orb_token_count()

            self._lbl_tokens.setText(str(tokens))
            self._lbl_threads.setText(str(threads))
            self._lbl_solver.setText(solver)

            self._cfg_labels["orb_enabled"].setText("Yes" if orb.get("enabled", True) else "No")
            self._cfg_labels["auto_claim"].setText("Yes" if orb.get("auto_claim", True) else "No")
            self._cfg_labels["threads"].setText(str(threads))
            self._cfg_labels["solver"].setText(solver)
            self._cfg_labels["api_key"].setText(api_key)
            self._cfg_labels["orb_quest_ids"].setText(
                ", ".join(str(q) for q in orb_qids) if orb_qids else "—"
            )
        except Exception:
            pass

    # ── Slots ─────────────────────────────────────────────────────────────────
    def _on_start(self):
        self.launchRequested.emit()

    def _on_stop(self):
        self.stopRequested.emit()

