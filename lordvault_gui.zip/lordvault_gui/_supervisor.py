"""Private stdio/console supervisor; deliberately imports no backend modules.

stdin/stdout speak JSON only to the GUI. The launched command receives ordinary
pipes and an isolated Windows console, preserving input() and Ctrl+C semantics.
"""

from __future__ import annotations

import codecs
import ctypes
import json
import os
import signal
import subprocess
import sys
import threading


_output_lock = threading.Lock()


def emit(kind: str, **values):
    try:
        with _output_lock:
            sys.stdout.write(json.dumps({"type": kind, **values}, ensure_ascii=True) + "\n")
            sys.stdout.flush()
    except (BrokenPipeError, OSError):
        pass


class WindowsJob:
    """A kernel-owned guarantee that stopping the helper leaves no workers."""

    def __init__(self):
        from ctypes import wintypes

        class BASIC(ctypes.Structure):
            _fields_ = [
                ("PerProcessUserTimeLimit", ctypes.c_int64),
                ("PerJobUserTimeLimit", ctypes.c_int64),
                ("LimitFlags", wintypes.DWORD),
                ("MinimumWorkingSetSize", ctypes.c_size_t),
                ("MaximumWorkingSetSize", ctypes.c_size_t),
                ("ActiveProcessLimit", wintypes.DWORD),
                ("Affinity", ctypes.c_size_t),
                ("PriorityClass", wintypes.DWORD),
                ("SchedulingClass", wintypes.DWORD),
            ]

        class IO(ctypes.Structure):
            _fields_ = [(name, ctypes.c_uint64) for name in (
                "ReadOperationCount", "WriteOperationCount", "OtherOperationCount",
                "ReadTransferCount", "WriteTransferCount", "OtherTransferCount",
            )]

        class EXTENDED(ctypes.Structure):
            _fields_ = [
                ("BasicLimitInformation", BASIC), ("IoInfo", IO),
                ("ProcessMemoryLimit", ctypes.c_size_t), ("JobMemoryLimit", ctypes.c_size_t),
                ("PeakProcessMemoryUsed", ctypes.c_size_t), ("PeakJobMemoryUsed", ctypes.c_size_t),
            ]

        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
        kernel.CreateJobObjectW.restype = wintypes.HANDLE
        kernel.SetInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
        kernel.SetInformationJobObject.restype = wintypes.BOOL
        kernel.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
        kernel.AssignProcessToJobObject.restype = wintypes.BOOL
        kernel.TerminateJobObject.argtypes = [wintypes.HANDLE, wintypes.UINT]
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        self.kernel = kernel
        self.handle = kernel.CreateJobObjectW(None, None)
        if not self.handle:
            raise ctypes.WinError(ctypes.get_last_error())
        limits = EXTENDED()
        limits.BasicLimitInformation.LimitFlags = 0x2000  # KILL_ON_JOB_CLOSE
        if not kernel.SetInformationJobObject(self.handle, 9, ctypes.byref(limits), ctypes.sizeof(limits)):
            error = ctypes.WinError(ctypes.get_last_error())
            self.close()
            raise error

    def assign(self, process):
        if not self.kernel.AssignProcessToJobObject(self.handle, int(process._handle)):
            raise ctypes.WinError(ctypes.get_last_error())

    def kill(self):
        if self.handle:
            self.kernel.TerminateJobObject(self.handle, 130)

    def close(self):
        if self.handle:
            self.kernel.CloseHandle(self.handle)
            self.handle = None


def main() -> int:
    command = json.loads(sys.argv[1])
    # A callable handler survives our own console event without setting the
    # inheritable Windows "ignore Ctrl+C" flag on the actual backend process.
    signal.signal(signal.SIGINT, lambda *_: None)
    job = None
    if os.name == "nt":
        try:
            job = WindowsJob()
        except OSError as exc:
            emit("error", text=f"Unable to create a worker cleanup job: {exc}")
            return 1
    options = {"start_new_session": True} if os.name != "nt" else {}
    try:
        process = subprocess.Popen(
            command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, bufsize=0, **options,
        )
        if job:
            try:
                job.assign(process)
            except OSError:
                process.kill()
                process.wait()
                raise
    except Exception as exc:
        emit("error", text=f"Could not start the workspace: {exc}")
        if job:
            job.close()
        return 1

    ended = threading.Event()
    stop_started = threading.Event()

    def kill():
        if job:
            job.kill()
        else:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass

    def stop():
        if ended.is_set() or stop_started.is_set():
            return
        stop_started.set()
        if os.name == "nt":
            sent = ctypes.windll.kernel32.GenerateConsoleCtrlEvent(0, 0)
            if not sent:
                emit("error", text="Unable to signal the workspace; automatic cleanup will follow.")
        else:
            try:
                os.killpg(process.pid, signal.SIGINT)
            except ProcessLookupError:
                return

        def deadline():
            if not ended.wait(8):
                emit("output", text="\nSYSTEM  Workspace did not stop within 8 seconds; closing its workers.\n")
                kill()

        threading.Thread(target=deadline, daemon=True).start()

    def control():
        try:
            for raw in sys.stdin:
                try:
                    record = json.loads(raw)
                    kind = record.get("type")
                    if kind == "input" and process.poll() is None:
                        process.stdin.write((str(record.get("text", "")) + "\n").encode("utf-8"))
                        process.stdin.flush()
                    elif kind == "stop":
                        stop()
                    elif kind == "kill":
                        kill()
                except (ValueError, OSError, BrokenPipeError):
                    continue
        finally:
            # Parent exited or closed its pipe: do not orphan active workers.
            if not ended.is_set():
                kill()

    emit("started", pid=process.pid)
    threading.Thread(target=control, daemon=True, name="LordVault-input").start()
    def pump():
        decoder = codecs.getincrementaldecoder("utf-8")("replace")
        while True:
            chunk = process.stdout.read(4096)
            if not chunk:
                break
            text = decoder.decode(chunk)
            if text:
                emit("output", text=text)
        tail = decoder.decode(b"", final=True)
        if tail:
            emit("output", text=tail)

    reader = threading.Thread(target=pump, daemon=True, name="LordVault-output")
    reader.start()
    try:
        code = process.wait()
        ended.set()
        # Descendants can inherit stdout. Reap them before waiting for pipe EOF.
        if job:
            job.close()
        else:
            kill()
        reader.join(timeout=2)
        emit("finished", code=code)
        return code
    finally:
        ended.set()
        if job:
            job.close()
        else:
            kill()
        for stream in (process.stdin, process.stdout):
            if stream:
                stream.close()


if __name__ == "__main__":
    sys.exit(main())
