"""Desktop startup before any backend imports or side effects."""

import importlib.util
import os
from pathlib import Path
import shutil
import subprocess
import sys


def _notify_failure(message):
    if os.name == 'nt':
        import ctypes
        ctypes.windll.user32.MessageBoxW(None, message, 'LORDVAULT | Startup', 0x10)
    elif sys.stderr:
        print(message, file=sys.stderr)


def _hide_owned_console():
    """Hide only a console owned exclusively by this Python process."""
    if os.name != 'nt':
        return
    try:
        import ctypes
        from ctypes import wintypes
        kernel = ctypes.windll.kernel32
        kernel.GetConsoleWindow.restype = wintypes.HWND
        pids = (wintypes.DWORD * 8)()
        count = kernel.GetConsoleProcessList(pids, 8)
        if count == 1 and pids[0] == os.getpid():
            handle = kernel.GetConsoleWindow()
            if handle:
                ctypes.windll.user32.ShowWindow(handle, 0)
    except (AttributeError, OSError):
        pass


def launch():
    if importlib.util.find_spec('PySide6') is None:
        # The existing project uses Python 3.12. A .py association may instead
        # resolve to another installed interpreter; find the configured runtime.
        launcher = shutil.which('py') if os.name == 'nt' else None
        if launcher:
            check = subprocess.run(
                [launcher, '-3.12', '-c',
                 'import importlib.util,sys; sys.exit(0 if importlib.util.find_spec("PySide6") else 1)'],
                capture_output=True, timeout=15,
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            if check.returncode == 0:
                command = [launcher, '-3.12', str(Path(__file__).resolve().parents[1] / 'main.py'), *sys.argv[1:]]
                # Wait so command-line callers and smoke tests see completion.
                _hide_owned_console()
                return subprocess.call(command, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        _notify_failure('LORDVAULT needs PySide6.\n\nInstall the project dependencies:\n'
                        'py -3.12 -m pip install -r requirements.txt\n\nThen run main.py again.')
        return 1
    _hide_owned_console()
    try:
        from .app import run
        return run()
    except Exception as error:
        import traceback
        details = traceback.format_exc()
        try:
            error_file = Path(__file__).resolve().parents[1] / 'output' / 'desktop-startup-error.log'
            error_file.parent.mkdir(parents=True, exist_ok=True)
            error_file.write_text(details, encoding='utf-8')
        except OSError:
            pass
        if sys.stderr:
            print(details, file=sys.stderr)
        # Automated UI checks should fail rather than wait for a modal dialog.
        if '--smoke-test' not in sys.argv:
            _notify_failure(f'The desktop could not start:\n{error}\n\n'
                            'See output/desktop-startup-error.log for details.')
        return 1
