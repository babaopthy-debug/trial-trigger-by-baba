"""LORDVAULT desktop presentation. Backend modules remain independent."""

