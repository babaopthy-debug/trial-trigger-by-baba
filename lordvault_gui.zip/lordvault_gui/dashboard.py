"""Overview and quick actions, using the existing terminal snapshot."""

import math
import time

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QColor, QPainter, QPen
from PySide6.QtWidgets import QFrame, QHBoxLayout, QVBoxLayout, QWidget

from .components import (LordVaultButton, LordVaultLogConsole, LordVaultLogo,
                          LordVaultProgress, LordVaultStatusCard, label)
from .theme import ACCENT, MUTED


class LordVaultActionMenu(QFrame):
    activated = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName('panel')
        self.setMinimumWidth(240)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 17, 14, 10)
        layout.setSpacing(2)
        title_row = QHBoxLayout()
        title_row.setContentsMargins(6, 0, 6, 10)
        title_row.addWidget(label('Quick actions', 'sectionTitle'))
        title_row.addStretch()
        title_row.addWidget(label('01 — 05', 'eyebrow'))
        layout.addLayout(title_row)
        self.buttons = []
        actions = [('launch', 'Launch LordVault', 'Open your workspace',    '#22c55e'),
                   ('tokens', 'Token Manager',     'View counts and formats','#f59e0b'),
                   ('config', 'Configuration',     'Review your settings',   '#c084fc'),
                   ('guide',  'Quick Start Guide', 'Setup and essentials',   '#f43f5e'),
                   ('exit',   'Exit LordVault',    'Close LordVault',        '#ef4444')]
        for index, (key, title, subtitle, accent) in enumerate(actions, 1):
            button = LordVaultButton(title, subtitle, str(index).zfill(2), accent)
            button.clicked.connect(lambda checked=False, k=key: self.activated.emit(k))
            layout.addWidget(button)
            self.buttons.append(button)
        layout.addStretch()


class LordVaultDashboard(QWidget):
    activated = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName('page')
        self.motion = True
        self.started = time.monotonic()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(10)
        self.logo = LordVaultLogo()
        layout.addWidget(self.logo)
        heading = QHBoxLayout()
        heading.addWidget(label('Your workspace', 'sectionTitle'))
        heading.addStretch()
        heading.addWidget(label('LOCAL OVERVIEW', 'eyebrow'))
        layout.addLayout(heading)
        cards = QHBoxLayout()
        cards.setSpacing(12)
        self.cards = [LordVaultStatusCard('TOKENS LOADED', 'tokens', '#38bdf8'),
                       LordVaultStatusCard('ORB TOKENS',    'tokens', '#f59e0b'),
                       LordVaultStatusCard('WORKERS',       'workers', '#22c55e')]
        for card in self.cards:
            cards.addWidget(card, 1)
        layout.addLayout(cards)
        self.status_frame = QFrame()
        self.status_frame.setObjectName('panel')
        status = QHBoxLayout(self.status_frame)
        status.setContentsMargins(17, 10, 17, 10)
        status.setSpacing(22)
        self.flags = {}
        for key, name in [('quests', 'Quests'), ('proxy', 'Proxy'), ('orb_buyer', 'Orbs Buyer')]:
            value = label(name)
            status.addWidget(value)
            self.flags[key] = (name, value)
        status.addStretch()
        self.uptime = label('UPTIME  00:00:00', 'eyebrow')
        status.addWidget(self.uptime)
        layout.addWidget(self.status_frame)
        lower = QHBoxLayout()
        lower.setSpacing(15)
        self.actions = LordVaultActionMenu()
        self.actions.activated.connect(self.activated)
        lower.addWidget(self.actions, 4)
        self.console = LordVaultLogConsole()
        lower.addWidget(self.console, 6)
        layout.addLayout(lower, 1)
        self.progress = LordVaultProgress()
        layout.addWidget(self.progress)
        footer = QHBoxLayout()
        self.status = label('●  Ready when you are', 'muted')
        self.status.setStyleSheet('font-size: 11px; color: #8e8e96;')
        footer.addWidget(self.status)
        footer.addStretch()
        hint = label('ALT + 1–5  ACTIONS     CTRL + R  REFRESH', 'eyebrow')
        hint.setStyleSheet('font-size: 9px; color: #71717a; letter-spacing: 0px;')
        footer.addWidget(hint)
        layout.addLayout(footer)
        self.timer = QTimer(self)
        self.timer.setInterval(1000)
        self.timer.timeout.connect(self._tick)
        self.timer.start()
        self.pulse = QTimer(self)
        self.pulse.setInterval(100)
        self.pulse.timeout.connect(self._border_pulse)
        self.pulse.start()

    def _tick(self):
        elapsed = int(time.monotonic() - self.started)
        hours, remainder = divmod(elapsed, 3600)
        minutes, seconds = divmod(remainder, 60)
        self.uptime.setText(f'UPTIME  {hours:02}:{minutes:02}:{seconds:02}')

    def _border_pulse(self):
        if not self.isVisible() or self.window().isMinimized():
            return
        amount = (math.sin(time.monotonic() * .9) + 1) / 2 if self.motion else .2
        val = int(36 + amount * 12)
        edge = f'#{val:02x}{val:02x}{val+2:02x}'
        self.status_frame.setStyleSheet(
            f'QFrame#panel {{ border: 1px solid {edge}; background: #121215; border-radius: 8px; }}')

    def refresh(self, data):
        for card, key in zip(self.cards, ('tokens', 'orbs', 'workers')):
            card.set_count(data.get(key, 0))
        for key, (name, value) in self.flags.items():
            enabled = data.get(key, False)
            color = "#f4f4f5" if enabled else "#71717a"
            bg = "#222228" if enabled else "#16161a"
            value.setText(f'<span style="color:#8e8e96">{name}</span>'
                          f'  <span style="color:{color};background:{bg};padding:1px 5px;border-radius:3px;font-weight:600;font-size:10px">{"ON" if enabled else "OFF"}</span>')

    def set_motion(self, enabled):
        self.motion = enabled
        self.logo.set_motion(enabled)
        self.pulse.start() if enabled else self.pulse.stop()
        self._border_pulse()
        self.progress.motion = enabled
        self.progress.timer.start() if self.progress.busy and enabled else self.progress.timer.stop()
        self.progress.update()
        for card in self.cards:
            card.motion = enabled
            if not enabled:
                card.animation.stop()
                card.count = card._target or 0

