"""Small, reusable widgets for the LORDVAULT desktop shell."""

import math
import re
import time
from collections import deque
from datetime import datetime

from PySide6.QtCore import (QEasingCurve, QPoint, Property, QPropertyAnimation,
                            QRectF, Qt, QTimer, Signal)
from PySide6.QtGui import (QColor, QFont, QLinearGradient, QPainter, QPainterPath,
                           QPen, QTextBlockFormat, QTextCharFormat, QTextCursor)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QComboBox, QFrame, QHBoxLayout, QLabel,
                               QLineEdit, QPlainTextEdit, QPushButton, QVBoxLayout, QWidget)

import lv_theme
from .theme import ACCENT, BORDER, CYAN, DISABLED, ERROR, MUTED, PANEL, PINK, PURPLE, SUCCESS, TEXT, WARNING


def label(text, name='', parent=None):
    widget = QLabel(text, parent)
    if name:
        widget.setObjectName(name)
    return widget


def mono(size=10):
    font = QFont('Cascadia Mono', size)
    font.setStyleHint(QFont.StyleHint.Monospace)
    return font


class LordVaultLogo(QWidget):
    """The original terminal glyphs rendered as a smooth, scalable wordmark."""

    def __init__(self, parent=None, motion=True):
        super().__init__(parent)
        self.setMinimumHeight(115)
        self.setAccessibleName('LORDVAULT. Your workspace. One command away.')
        self.motion = motion
        self.started = time.monotonic()
        self.timer = QTimer(self)
        self.timer.setInterval(40)
        self.timer.timeout.connect(self._tick)
        if motion:
            self.timer.start()

    def _tick(self):
        if self.isVisible() and not self.window().isMinimized():
            self.update()

    def set_motion(self, enabled):
        self.motion = enabled
        self.timer.start() if enabled else self.timer.stop()
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        width, height = self.width(), self.height()
        elapsed = time.monotonic() - self.started
        phase = math.sin(elapsed * .35) if self.motion else 0
        grid_pen = QPen(QColor('#1c1c20'))
        painter.setPen(grid_pen)
        for x in range(18, width, 24):
            for y in range(8, height - 8, 24):
                painter.drawPoint(x, y)
        # Quiet frame corners keep the identity of the terminal banner.
        painter.setPen(QPen(QColor('#33333a'), 1))
        for x, direction in ((0, 1), (width - 1, -1)):
            painter.drawLine(x, 16, x + direction * 13, 16)
            painter.drawLine(x, 16, x, 27)
            painter.drawLine(x, height - 16, x + direction * 13, height - 16)
            painter.drawLine(x, height - 16, x, height - 27)
        painter.setFont(mono(8))
        painter.setPen(QColor('#71717a'))
        painter.drawText(QRectF(0, 4, width, 16), Qt.AlignmentFlag.AlignCenter,
                         'L O R D V A U L T   / /   C O N T R O L  C E N T E R')
        cell = min(9.8, (width - 100) / 53)
        left = (width - 53 * cell) / 2
        top = 30
        gradient = QLinearGradient(left, 0, left + 53 * cell, 0)
        gradient.setColorAt(0, QColor('#71717a'))
        gradient.setColorAt(.5 + phase * .05, QColor('#d4d4d8'))
        gradient.setColorAt(1, QColor('#e4e4e7'))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(gradient)
        reveal = min(1, elapsed / .65) if self.motion else 1
        painter.setOpacity(.96)
        for row_index, row in enumerate(lv_theme.BANNER_ROWS):
            for col, character in enumerate(row):
                if character != ' ' and col / 53 <= reveal:
                    painter.drawRoundedRect(QRectF(left + col * cell, top + row_index * cell,
                                                   cell - 1.3, cell - 1.3), .65, .65)
        painter.setOpacity(1)
        painter.setFont(mono(8))
        painter.setPen(QColor('#a1a1aa'))
        painter.drawText(QRectF(0, top + 5 * cell + 8, width, 18), Qt.AlignmentFlag.AlignCenter,
                         'YOUR WORKSPACE. ONE COMMAND AWAY.')


ICON_MAP = {
    'Overview': '⊞',
    'Workspace': '⚡',
    'Token Manager': '⬡',
    'Configuration': '⚙',
    'Orb Claimer': '◈',
    'Quick Start': '✦',
    'Quick Start Guide': '✦',
    'Launch LordVault': '⚡',
    'Exit LordVault': '✕',
}

ACCENT_MAP = {
    'Overview': '#38bdf8',          # Sky cyan / blue
    'Workspace': '#22c55e',         # Emerald green
    'Token Manager': '#f59e0b',     # Amber gold
    'Configuration': '#c084fc',     # Violet purple
    'Orb Claimer': '#f43f5e',       # Rose — orb brand colour
    'Quick Start': '#f97316',       # Orange
    'Quick Start Guide': '#f97316', # Orange
    'Launch LordVault': '#22c55e',  # Green
    'Exit LordVault': '#ef4444',    # Red
}


class LordVaultButton(QPushButton):
    """Keyboard-accessible action with colorful icon badge and painted hover transition."""

    def __init__(self, title, subtitle='', number='', accent=None, icon='', parent=None):
        super().__init__(parent)
        self.title, self.subtitle, self.number = title, subtitle, number
        self.icon = icon or ICON_MAP.get(title, '')
        if accent is None or accent == PURPLE:
            self.accent = ACCENT_MAP.get(title, ACCENT)
        else:
            self.accent = accent
        self.selected = False
        self.motion = True
        self._hover = 0.
        self.setText(title)
        self.setAccessibleName(title)
        self.setAccessibleDescription(subtitle)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMinimumHeight(48 if subtitle else 38)
        self.animation = QPropertyAnimation(self, b'hover', self)
        self.animation.setDuration(140)
        self.animation.setEasingCurve(QEasingCurve.Type.OutCubic)

    @Property(float)
    def hover(self):
        return self._hover

    @hover.setter
    def hover(self, value):
        self._hover = value
        self.update()

    def _animate(self, value):
        self.animation.stop()
        if not self.motion:
            self.hover = value
            return
        self.animation.setStartValue(self.hover)
        self.animation.setEndValue(value)
        self.animation.start()

    def enterEvent(self, event):
        self._animate(1)
        super().enterEvent(event)

    def leaveEvent(self, event):
        self._animate(0)
        super().leaveEvent(event)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        area = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        active = max(self._hover, .85 if self.selected else 0)

        # Base container
        if self.selected:
            painter.setBrush(QColor('#12151e'))
            painter.setPen(QPen(QColor(self.accent), 1.5))
            painter.drawRoundedRect(area, 6, 6)
        elif active:
            fill = QColor(self.accent)
            fill.setAlpha(int(20 + active * 45))
            painter.setBrush(fill)
            edge = QColor(self.accent)
            edge.setAlpha(int(70 + active * 110))
            painter.setPen(QPen(edge, 1))
            painter.drawRoundedRect(area, 6, 6)
        else:
            painter.setBrush(QColor('#090a0d'))
            painter.setPen(QPen(QColor('#1f242e'), 1))
            painter.drawRoundedRect(area, 6, 6)

        if self.hasFocus() and not self.selected:
            painter.setPen(QPen(QColor(self.accent), 1))
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawRoundedRect(area, 6, 6)

        # Left Icon / Symbol Badge
        icon_y = (self.height() - 26) / 2
        badge_rect = QRectF(8, icon_y, 26, 26)
        badge_fill = QColor(self.accent)
        badge_fill.setAlpha(36 if (self.selected or active) else 18)
        painter.setBrush(badge_fill)
        badge_edge = QColor(self.accent if (self.selected or active) else '#2a313d')
        painter.setPen(QPen(badge_edge, 1.2 if (self.selected or active) else 1.0))
        painter.drawRoundedRect(badge_rect, 5, 5)

        if self.icon:
            painter.setFont(QFont('Segoe UI Symbol', 11, QFont.Weight.DemiBold))
            painter.setPen(QColor(self.accent))
            painter.drawText(badge_rect, Qt.AlignmentFlag.AlignCenter, self.icon)
        else:
            painter.setFont(mono(8))
            painter.setPen(QColor(self.accent))
            painter.drawText(badge_rect, Qt.AlignmentFlag.AlignCenter, self.number)

        # Title Label
        painter.setFont(QFont('Segoe UI', 9, QFont.Weight.DemiBold))
        text_color = '#ffffff' if self.selected else ('#f5f7fa' if self.isEnabled() else '#666d78')
        painter.setPen(QColor(text_color))
        painter.drawText(QRectF(42, 6 if self.subtitle else 0, self.width() - 84, 18 if self.subtitle else self.height()),
                         Qt.AlignmentFlag.AlignVCenter, self.title)

        # Subtitle (if present)
        if self.subtitle:
            painter.setFont(QFont('Segoe UI', 8))
            painter.setPen(QColor('#94a3b8' if self.selected else '#71717a'))
            painter.drawText(QRectF(42, 26, self.width() - 84, 16), Qt.AlignmentFlag.AlignVCenter, self.subtitle)

        # Right number & arrow indicator
        if self.number and self.icon:
            painter.setFont(mono(8))
            painter.setPen(QColor(self.accent if self.selected else '#64748b'))
            painter.drawText(QRectF(self.width() - 42, 0, 22, self.height()), Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignRight, self.number)

        painter.setPen(QColor(self.accent if (self.selected or active) else '#383f4d'))
        painter.setFont(QFont('Segoe UI', 11))
        painter.drawText(QRectF(self.width() - 18, 0, 12, self.height()), Qt.AlignmentFlag.AlignCenter, '›')
        painter.end()


class LordVaultToggle(QAbstractButton):
    """Modern smooth toggle switch with muted green ON and dark gray OFF states."""

    def __init__(self, checked=False, parent=None):
        super().__init__(parent)
        self.setCheckable(True)
        self.setChecked(checked)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFixedSize(38, 20)
        self._position = 1.0 if checked else 0.0
        self.animation = QPropertyAnimation(self, b'position', self)
        self.animation.setDuration(120)
        self.animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        self.toggled.connect(self._on_toggled)

    @Property(float)
    def position(self):
        return self._position

    @position.setter
    def position(self, val):
        self._position = val
        self.update()

    def _on_toggled(self, checked):
        motion = getattr(self, 'motion', True)
        if not motion:
            self._position = 1.0 if checked else 0.0
            self.update()
            return
        self.animation.stop()
        self.animation.setStartValue(self._position)
        self.animation.setEndValue(1.0 if checked else 0.0)
        self.animation.start()

    def setChecked(self, checked):
        super().setChecked(checked)
        self._position = 1.0 if checked else 0.0
        self.update()

    def text(self):
        return 'ON' if self.isChecked() else 'OFF'

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        if self.animation.state() != QPropertyAnimation.State.Running:
            self._position = 1.0 if self.isChecked() else 0.0
        pos = self._position
        # Smooth interpolation between OFF (#1e222a) and ON (#43b581)
        r = int(30 + (67 - 30) * pos)
        g = int(34 + (181 - 34) * pos)
        b = int(42 + (129 - 42) * pos)
        track_color = QColor(r, g, b)
        border_color = QColor(r, g, b) if pos > 0.3 else QColor('#252a32')

        painter.setBrush(track_color)
        painter.setPen(QPen(border_color, 1))
        painter.drawRoundedRect(QRectF(1, 1, 36, 18), 9, 9)

        # Handle: diameter 14, Y = 3. Moves from X = 3 to X = 21
        x = 3 + 18 * pos
        hr = int(143 + (245 - 143) * pos)
        hg = int(152 + (247 - 152) * pos)
        hb = int(168 + (250 - 168) * pos)
        handle_color = QColor(hr, hg, hb)

        painter.setBrush(handle_color)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawEllipse(QRectF(x, 3, 14, 14))


class LordVaultToggleSwitch(QWidget):
    """Accessible switch row containing an animated switch and accompanying status text."""
    toggled = Signal(bool)

    def __init__(self, checked=False, parent=None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)

        self.toggle = LordVaultToggle(checked, self)
        self.label = QLabel('ON' if checked else 'OFF')
        self.label.setFont(QFont('Segoe UI', 9, QFont.Weight.DemiBold))
        self.label.setFixedWidth(28)
        self._update_label_style(checked)

        self.toggle.toggled.connect(self._on_toggled)

        layout.addWidget(self.toggle)
        layout.addWidget(self.label)
        layout.setAlignment(Qt.AlignmentFlag.AlignVCenter)

    def _update_label_style(self, checked):
        if checked:
            self.label.setText('ON')
            self.label.setStyleSheet('color: #43b581; font-weight: 600; font-size: 10px;')
        else:
            self.label.setText('OFF')
            self.label.setStyleSheet('color: #666d78; font-weight: 600; font-size: 10px;')

    def _on_toggled(self, checked):
        self._update_label_style(checked)
        self.toggled.emit(checked)

    def isChecked(self):
        return self.toggle.isChecked()

    def setChecked(self, checked):
        self.toggle.setChecked(checked)
        self._update_label_style(checked)

    def text(self):
        return 'ON' if self.toggle.isChecked() else 'OFF'

    def mousePressEvent(self, event):
        self.toggle.click()


class LordVaultStatusCard(QFrame):
    def __init__(self, title, unit, accent=ACCENT, parent=None):
        super().__init__(parent)
        self.setObjectName('panel')
        self.unit, self.accent = unit, accent
        self._count, self._target = 0., None
        self.motion = True
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 10, 16, 11)
        layout.setSpacing(4)
        title_label = label('●  ' + title, 'eyebrow')
        title_label.setStyleSheet(f'color: {accent}; font-size: 8px; letter-spacing: 1.5px;')
        layout.addWidget(title_label)
        row = QHBoxLayout()
        self.value = label('0')
        self.value.setStyleSheet('font-size: 26px; font-weight: 600; color: #f4f4f5;')
        row.addWidget(self.value)
        unit_lbl = label(unit, 'muted')
        unit_lbl.setStyleSheet('color: #8e8e96; font-size: 10px;')
        row.addWidget(unit_lbl, 1, Qt.AlignmentFlag.AlignBottom)
        layout.addLayout(row)
        self.animation = QPropertyAnimation(self, b'count', self)
        self.animation.setDuration(550)
        self.animation.setEasingCurve(QEasingCurve.Type.OutCubic)

    @Property(float)
    def count(self):
        return self._count

    @count.setter
    def count(self, value):
        self._count = value
        self.value.setText(f'{round(value):,}')

    def set_count(self, value):
        try:
            value = max(0, int(value))
        except (TypeError, ValueError):
            value = 0
        if value == self._target:
            return
        self._target = value
        self.animation.stop()
        if self.motion:
            self.animation.setStartValue(self.count)
            self.animation.setEndValue(value)
            self.animation.start()
        else:
            self.count = value


class LordVaultProgress(QWidget):
    """An honest idle/busy indicator, with determinate progress when reported."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(4)
        self.busy = False
        self.motion = True
        self._value = 0.
        self._phase = 0.
        self.animation = QPropertyAnimation(self, b'value', self)
        self.animation.setDuration(260)
        self.animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        self.timer = QTimer(self)
        self.timer.setInterval(40)
        self.timer.timeout.connect(self._tick)

    @Property(float)
    def value(self):
        return self._value

    @value.setter
    def value(self, value):
        self._value = value
        self.update()

    def set_progress(self, current, total):
        if total <= 0:
            return
        self.busy = False
        self.timer.stop()
        target = max(0., min(1., current / total))
        self.animation.stop()
        if self.motion:
            self.animation.setStartValue(self.value)
            self.animation.setEndValue(target)
            self.animation.start()
        else:
            self.value = target

    def set_busy(self, busy):
        self.animation.stop()
        self.busy = busy
        self._value = 0
        self.timer.start() if busy and self.motion else self.timer.stop()
        self.update()

    def _tick(self):
        if self.isVisible() and not self.window().isMinimized():
            self._phase = (self._phase + .012) % 1
            self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor('#18181c'))
        gradient = QLinearGradient(0, 0, self.width(), 0)
        gradient.setColorAt(0, QColor('#52525b'))
        gradient.setColorAt(1, QColor('#d4d4d8'))
        if self.busy:
            x = (self.width() + self.width() * .25) * self._phase - self.width() * .25 if self.motion else 0
            painter.fillRect(QRectF(x, 0, self.width() * .25, 4), gradient)
        else:
            painter.fillRect(QRectF(0, 0, self.width() * self._value, 4), gradient)


class LordVaultLogConsole(QFrame):
    # Level badge color (bright, vivid)
    COLORS = {
        'INFO':    '#60a5fa',  # bright sky blue
        'SUCCESS': '#4ade80',  # vivid emerald
        'WARNING': '#fbbf24',  # bright amber
        'ERROR':   '#f87171',  # vivid red
        'VERIFY':  '#22d3ee',  # bright cyan
        'SYSTEM':  '#94a3b8',  # muted silver
    }
    # Message text color (slightly softer)
    MSG_COLORS = {
        'INFO':    '#e0eeff',
        'SUCCESS': '#d1fae5',
        'WARNING': '#fef3c7',
        'ERROR':   '#fee2e2',
        'VERIFY':  '#cffafe',
        'SYSTEM':  '#cbd5e1',
    }
    # Row background tint (very subtle)
    ROW_BG = {
        'INFO':    '#0d1520',
        'SUCCESS': '#0a1f12',
        'WARNING': '#1c1800',
        'ERROR':   '#1f0a0a',
        'VERIFY':  '#07171e',
        'SYSTEM':  '#0e1117',
    }
    # Prefix symbol per level
    SYMBOLS = {
        'INFO':    'ℹ',
        'SUCCESS': '✔',
        'WARNING': '⚠',
        'ERROR':   '✗',
        'VERIFY':  '◎',
        'SYSTEM':  '▪',
    }
    ALIASES = {
        'OK': 'SUCCESS', 'WARN': 'WARNING', 'ERR': 'ERROR', 'FAIL': 'ERROR',
        'FATAL': 'ERROR', 'CRITICAL': 'ERROR',
        'DBG': 'SYSTEM', 'DEBUG': 'SYSTEM', 'SETUP': 'SYSTEM', 'READY': 'SUCCESS',
        'VERIFY': 'VERIFY', 'PASS': 'SUCCESS', 'LOGIN': 'SUCCESS',
    }

    def __init__(self, title='Live activity', parent=None):
        super().__init__(parent)
        self.setObjectName('panel')
        self.records = deque(maxlen=1500)
        self._pending = deque(maxlen=3000)
        self._pending_ts = None
        self.chips = {}

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 12, 14, 10)
        layout.setSpacing(8)

        heading = QHBoxLayout()
        heading.setSpacing(8)
        heading.addWidget(label(title, 'sectionTitle'))

        self.count_badge = QLabel('0 events')
        self.count_badge.setStyleSheet(
            'background: #141416; color: #8e8e98; font-size: 10px; font-weight: 500; '
            'padding: 1px 7px; border-radius: 8px; border: 1px solid #24242c;'
        )
        heading.addWidget(self.count_badge)
        heading.addStretch()

        live = label('● LIVE', 'eyebrow')
        live.setStyleSheet(
            'background: #111114; color: #b4b4be; font-size: 9px; '
            'font-weight: 700; letter-spacing: 1px; padding: 2px 8px; border-radius: 9px; '
            'border: 1px solid #282832;'
        )
        heading.addWidget(live)
        layout.addLayout(heading)

        toolbar = QHBoxLayout()
        toolbar.setSpacing(6)

        self.filter = QComboBox()
        self.filter.addItems(['All events', *self.COLORS])
        self.filter.setAccessibleName('Filter activity by level')
        self.filter.setStyleSheet(
            'QComboBox { background: #0d0d10; border: 1px solid #24242c; border-radius: 5px; '
            'padding: 3px 6px; color: #dedee6; font-size: 11px; min-width: 78px; } '
            'QComboBox:hover { border-color: #444450; }'
        )
        self.filter.currentTextChanged.connect(self._on_filter_changed)
        toolbar.addWidget(self.filter)

        self.search = QLineEdit()
        self.search.setPlaceholderText('Filter activity...')
        self.search.setClearButtonEnabled(True)
        self.search.setStyleSheet(
            'QLineEdit { background: #0d0d10; border: 1px solid #24242c; border-radius: 5px; '
            'padding: 4px 8px; color: #dedee6; font-size: 11px; } '
            'QLineEdit:focus { border-color: #dedee6; background: #141418; }'
        )
        self.search.textChanged.connect(self._rebuild)
        toolbar.addWidget(self.search, 1)

        self.copy_btn = QPushButton('Copy')
        self.copy_btn.setFixedHeight(26)
        self.copy_btn.setToolTip('Copy visible activity logs to clipboard')
        self.copy_btn.setStyleSheet(
            'QPushButton { background: #0d0d10; border: 1px solid #24242c; border-radius: 5px; '
            'padding: 2px 8px; color: #dedee6; font-size: 11px; font-weight: 500; } '
            'QPushButton:hover { background: #1a1a20; border-color: #444450; }'
        )
        self.copy_btn.clicked.connect(self.copy_logs)
        toolbar.addWidget(self.copy_btn)

        clear = QPushButton('Clear')
        clear.setFixedHeight(26)
        clear.setToolTip('Clear the visible activity history')
        clear.setStyleSheet(
            'QPushButton { background: #0d0d10; border: 1px solid #24242c; border-radius: 5px; '
            'padding: 2px 8px; color: #dedee6; font-size: 11px; font-weight: 500; } '
            'QPushButton:hover { background: #261418; color: #ff8888; border-color: #552226; }'
        )
        clear.clicked.connect(self.clear)
        toolbar.addWidget(clear)
        layout.addLayout(toolbar)

        self.text = QPlainTextEdit()
        self.text.setReadOnly(True)
        self.text.setMaximumBlockCount(1500)
        self.text.setMinimumHeight(120)
        self.text.setPlaceholderText('Waiting for workspace activity and event logs...')
        self.text.setAccessibleName(title)
        self.text.setStyleSheet(
            'QPlainTextEdit { background: #000000; border: 1px solid #222222; border-radius: 8px; '
            'color: #b4b4be; font-family: "Cascadia Code", "JetBrains Mono", "Consolas", monospace; '
            'font-size: 12px; padding: 8px 10px; selection-background-color: #2c2c36; selection-color: #ffffff; }'
        )
        layout.addWidget(self.text, 1)

        bottom_bar = QHBoxLayout()
        bottom_bar.setSpacing(4)

        legend_label = QLabel('FILTER:')
        legend_label.setStyleSheet('font-size: 9px; font-weight: 600; color: #6a6a76; letter-spacing: 0.5px;')
        bottom_bar.addWidget(legend_label)

        all_chip = QPushButton('ALL')
        all_chip.setToolTip('Show all events')
        all_chip.clicked.connect(lambda: self.filter.setCurrentText('All events'))
        self.chips['All events'] = all_chip
        bottom_bar.addWidget(all_chip)

        for lvl in self.COLORS:
            btn = QPushButton(lvl)
            btn.setToolTip(f'Filter events by {lvl}')
            btn.clicked.connect(lambda checked=False, l=lvl: self.filter.setCurrentText(l))
            self.chips[lvl] = btn
            bottom_bar.addWidget(btn)

        bottom_bar.addStretch()
        autoscroll_lbl = QLabel('AUTO-SCROLL')
        autoscroll_lbl.setStyleSheet('font-size: 9px; font-weight: 600; color: #787884; letter-spacing: 0.5px;')
        bottom_bar.addWidget(autoscroll_lbl)
        layout.addLayout(bottom_bar)

        self._update_chip_styles('All events')

        self.flush_timer = QTimer(self)
        self.flush_timer.setInterval(60)
        self.flush_timer.timeout.connect(self.flush_pending)
        self.flush_timer.start()

    def _update_chip_styles(self, active_level):
        chip_theme = {
            'All events': ('#f5f7fa', '#1e232e', '#383f4c'),
            'INFO':       ('#60a5fa', '#142238', '#2563eb'),
            'SUCCESS':    ('#4ade80', '#122a1c', '#16a34a'),
            'WARNING':    ('#facc15', '#2a2410', '#ca8a04'),
            'ERROR':      ('#f87171', '#2d1519', '#dc2626'),
            'VERIFY':     ('#38bdf8', '#102636', '#0284c7'),
            'SYSTEM':     ('#cbd5e1', '#1c212a', '#475569'),
        }
        for lvl, btn in self.chips.items():
            is_active = (lvl == active_level)
            fg, bg, border = chip_theme.get(lvl, ('#dedee6', '#141418', '#24242c'))
            if is_active:
                btn.setStyleSheet(
                    f'background: {bg}; color: {fg}; border: 1px solid {border}; '
                    'border-radius: 4px; padding: 2px 7px; font-size: 9px; font-weight: 700;'
                )
            else:
                btn.setStyleSheet(
                    'QPushButton { background: #0d0d10; color: #888892; border: 1px solid #222228; '
                    'border-radius: 4px; padding: 2px 7px; font-size: 9px; font-weight: 600; } '
                    f'QPushButton:hover {{ color: {fg}; border-color: {border}; background: #14161c; }}'
                )

    def _on_filter_changed(self, text):
        self._update_chip_styles(text)
        self._rebuild()

    def add(self, level, message, timestamp=None):
        level = self.ALIASES.get(level.upper(), level.upper())
        if level not in self.COLORS:
            level = 'SYSTEM'
        self._pending.append((timestamp or datetime.now().strftime('%H:%M:%S'), level, str(message)))

    def feed(self, text):
        for raw_line in lv_theme.strip_ansi(text).splitlines():
            line = raw_line.strip()
            if not line:
                continue

            # 1. Standalone timestamp on its own line: e.g. "08:12:05"
            ts_match = re.fullmatch(r'\[?(\d\d:\d\d:\d\d)\]?', line)
            if ts_match:
                self._pending_ts = ts_match.group(1)
                continue

            timestamp = self._pending_ts
            self._pending_ts = None

            # 2. Line starts with timestamp: e.g. "08:12:05 ERR ..." or "[09:50:07] SYSTEM   ..."
            match = re.match(r'^\[?(\d\d:\d\d:\d\d)\]?\s+(?:\[([A-Za-z_]+)\]|([A-Za-z_]+)[:\-]?)\s*[│|]?\s*(.*)', line)
            if match:
                ts, lvl1, lvl2, raw_msg = match.groups()
                level = (lvl1 or lvl2).upper()
                message = raw_msg.strip()
                timestamp = ts
            else:
                # 3. Line starts with log tag (no timestamp): e.g. "ERR Invalid...", "[ERROR] ...", "WARN ..."
                match_tag = re.match(r'^(?:\[([A-Za-z_]+)\]|([A-Za-z_]+)[:\-]?)\s*[│|]?\s*(.*)', line)
                tag = (match_tag.group(1) or match_tag.group(2)).upper() if match_tag else ''
                if match_tag and (tag in self.ALIASES or tag in self.COLORS):
                    level = tag
                    message = match_tag.group(3).strip()
                else:
                    level = 'SYSTEM'
                    message = line

            # Filter out bare separator lines (e.g. │ or | alone)
            if not message or re.fullmatch(r'[\u2502|\s]+', message):
                continue

            # 4. Smart upgrade of level from message content
            lower = message.lower()
            if level in ('SYSTEM', 'INFO', 'DBG', 'DEBUG', ''):
                if re.search(r'login\s+ok', lower) or re.search(r'logged\s+in', lower):
                    level = 'SUCCESS'
                elif re.fullmatch(r'(success|ok|done|passed|verified)', lower):
                    level = 'SUCCESS'
                elif re.search(r'login\s+(fail|error|invalid)', lower) or re.search(r'invalid\s+token', lower):
                    level = 'ERROR'
                elif any(k in lower for k in ('invalid server invite', 'error:', 'err:', 'fail:', 'failed to',
                                               'traceback (most recent call last)', 'exception', 'unauthorized')):
                    level = 'ERROR'
                elif any(k in lower for k in ('warning:', 'warn:', 'rate limit', 'retry', 'slow')):
                    level = 'WARNING'
                elif any(k in lower for k in ('ready:', 'valid:', 'connected to vc', 'session verified',
                                               'starting', 'initialized', 'loaded')):
                    level = 'SUCCESS'
                elif re.search(r'[A-Za-z0-9]{20,}\.[A-Za-z0-9_-]{4,}\.[A-Za-z0-9_-]{6,}', message):
                    level = 'VERIFY'

            level = self.ALIASES.get(level.upper(), level.upper())
            if 'validat' in message.lower() and re.search(r'\d+\s*/\s*\d+', message):
                level = 'VERIFY'

            self.add(level, message, timestamp)

    def flush_pending(self):
        if not self._pending:
            return
        scroll = self.text.verticalScrollBar()
        at_bottom = scroll.value() >= scroll.maximum() - 8
        for _ in range(min(150, len(self._pending))):
            record = self._pending.popleft()
            self.records.append(record)
            self._append(record)
        if at_bottom:
            scroll.setValue(scroll.maximum())
        self._update_counter()

    def _append(self, record):
        timestamp, level, message = record
        if self.filter.currentText() not in ('All events', level):
            return
        if hasattr(self, 'search') and self.search.text().strip():
            query = self.search.text().strip().lower()
            if query not in message.lower() and query not in level.lower() and query not in timestamp:
                return

        cursor = QTextCursor(self.text.document())
        cursor.movePosition(QTextCursor.MoveOperation.End)
        if not self.text.document().isEmpty():
            cursor.insertBlock()

        block_fmt = QTextBlockFormat()
        block_fmt.setTopMargin(3)
        block_fmt.setBottomMargin(3)
        block_fmt.setLineHeight(140, QTextBlockFormat.LineHeightTypes.ProportionalHeight.value)
        # Subtle row background tint
        row_bg = self.ROW_BG.get(level, '#0e1117')
        block_fmt.setBackground(QColor(row_bg))
        cursor.setBlockFormat(block_fmt)

        # Timestamp — dim gray
        fmt_ts = QTextCharFormat()
        fmt_ts.setForeground(QColor('#475569'))
        cursor.insertText(f'[{timestamp}] ', fmt_ts)

        # Colored symbol prefix + level badge
        lvl_color = self.COLORS.get(level, '#94a3b8')
        symbol    = self.SYMBOLS.get(level, '▪')
        fmt_lvl = QTextCharFormat()
        fmt_lvl.setForeground(QColor(lvl_color))
        fmt_lvl.setFontWeight(QFont.Weight.Bold)
        cursor.insertText(f'{symbol} {level:<7} ', fmt_lvl)

        # Separator
        fmt_sep = QTextCharFormat()
        fmt_sep.setForeground(QColor('#2d3748'))
        cursor.insertText('│ ', fmt_sep)

        # Message text - with smart inline token & status highlighting
        login_match = re.match(r'^(Login\s+OK)\s*(->|:)?\s*(.*)$', message, re.IGNORECASE)
        if login_match:
            tag, arrow, rest = login_match.groups()
            fmt_tag = QTextCharFormat()
            fmt_tag.setForeground(QColor('#4ade80'))
            fmt_tag.setFontWeight(QFont.Weight.Bold)
            cursor.insertText(tag, fmt_tag)
            if arrow:
                fmt_arrow = QTextCharFormat()
                fmt_arrow.setForeground(QColor('#64748b'))
                cursor.insertText(f' {arrow} ', fmt_arrow)
            if rest:
                fmt_tok = QTextCharFormat()
                fmt_tok.setForeground(QColor('#38bdf8'))
                cursor.insertText(rest, fmt_tok)
        else:
            fmt_msg = QTextCharFormat()
            msg_color = self.MSG_COLORS.get(level, '#e2e8f0')
            fmt_msg.setForeground(QColor(msg_color))
            if level in ('SUCCESS', 'ERROR'):
                fmt_msg.setFontWeight(QFont.Weight.Medium)
            cursor.insertText(message, fmt_msg)

    def _rebuild(self):
        self.text.clear()
        for record in self.records:
            self._append(record)
        self._update_counter()

    def _update_counter(self):
        total = len(self.records)
        curr_filter = self.filter.currentText()
        query = self.search.text().strip() if hasattr(self, 'search') else ''
        if curr_filter != 'All events' or query:
            lines = self.text.document().blockCount() if not self.text.document().isEmpty() else 0
            self.count_badge.setText(f'{lines} / {total} events')
        else:
            self.count_badge.setText(f'{total} events')

    def copy_logs(self):
        clipboard = QApplication.clipboard()
        if clipboard:
            clipboard.setText(self.text.toPlainText())
        self.copy_btn.setText('Copied')
        QTimer.singleShot(1500, lambda: self.copy_btn.setText('Copy'))

    def clear(self):
        self.records.clear()
        self._pending.clear()
        self._pending_ts = None
        self.text.clear()
        self._update_counter()


from .titlebar import LordVaultBadge, LordVaultTitleBar, LordVaultWindowButton


class LordVaultHeader(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName('header')
        self.setFixedHeight(57)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(28, 0, 28, 0)
        # Colorful title: LORD cyan, VAULT rose
        lord_lbl = label('LORD')
        lord_lbl.setStyleSheet('font-size: 11px; font-weight: 700; letter-spacing: 2px; color: #38bdf8;')
        layout.addWidget(lord_lbl)
        vault_lbl = label('VAULT')
        vault_lbl.setStyleSheet('font-size: 11px; font-weight: 700; letter-spacing: 2px; color: #f43f5e;')
        layout.addWidget(vault_lbl)
        cc_lbl = label('  CONTROL CENTER')
        cc_lbl.setStyleSheet('font-size: 11px; font-weight: 600; letter-spacing: 2px; color: #cbd5e1;')
        layout.addWidget(cc_lbl)
        layout.addStretch()
        self.state = label('●  WORKSPACE IDLE', 'eyebrow')
        self.state.setStyleSheet('color: #8e8e96; font-weight: 600; font-size: 9px; letter-spacing: 1px;')
        layout.addWidget(self.state)


class LordVaultSidebar(QFrame):
    selected = Signal(str)
    motion_changed = Signal(bool)

    def __init__(self, parent=None):
        super().__init__(parent)
        from PySide6.QtWidgets import QCheckBox
        self.setObjectName('sidebar')
        self.setFixedWidth(200)
        self.motion = True
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 22, 10, 18)
        layout.setSpacing(5)
        # Colorful brand: LORD in cyan, VAULT in rose
        brand_row = QHBoxLayout()
        brand_row.setContentsMargins(0, 0, 0, 0)
        brand_row.setSpacing(0)
        lord = label('  LORD')
        lord.setStyleSheet('font-size: 17px; font-weight: 700; letter-spacing: 1.5px; color: #38bdf8;')
        vault = label('VAULT')
        vault.setStyleSheet('font-size: 17px; font-weight: 700; letter-spacing: 1.5px; color: #f43f5e;')
        brand_row.addWidget(lord)
        brand_row.addWidget(vault)
        brand_row.addStretch()
        layout.addLayout(brand_row)
        tag = label('      CONTROL CENTER', 'eyebrow')
        tag.setStyleSheet('font-size: 8px; color: #38bdf8; letter-spacing: 1px; opacity: 0.7;')
        layout.addWidget(tag)
        layout.addSpacing(34)
        nav_label = label('   NAVIGATION', 'eyebrow')
        nav_label.setStyleSheet('font-size: 7px; color: #64748b; letter-spacing: 2px;')
        layout.addWidget(nav_label)
        layout.addSpacing(9)
        self.buttons = {}
        for key, title, symbol in [('dashboard', 'Overview', '01'), ('workspace', 'Workspace', '02'),
                                    ('tokens', 'Token Manager', '03'), ('config', 'Configuration', '04'),
                                    ('orb_claimer', 'Orb Claimer', '05'), ('guide', 'Quick Start', '06')]:

            # Each button picks up its icon and accent automatically from ICON_MAP/ACCENT_MAP
            button = LordVaultButton(title, number=symbol)
            button.clicked.connect(lambda checked=False, k=key: self.selected.emit(k))
            layout.addWidget(button)
            self.buttons[key] = button
        layout.addStretch()
        core = QFrame()
        core.setObjectName('panel')
        core_layout = QVBoxLayout(core)
        core_layout.setContentsMargins(14, 14, 14, 14)
        core_layout.addWidget(label('●  LORDVAULT CORE', 'eyebrow'))
        core_layout.addWidget(label('Local workspace', 'muted'))
        layout.addWidget(core)
        layout.addSpacing(14)
        self.motion_check = QCheckBox('Interface motion')
        self.motion_check.setChecked(True)
        self.motion_check.toggled.connect(self.motion_changed)
        layout.addWidget(self.motion_check)
        layout.addSpacing(13)
        exit_button = LordVaultButton('Exit LordVault', number='EXIT', accent=MUTED)
        exit_button.clicked.connect(lambda: self.selected.emit('exit'))
        layout.addWidget(exit_button)
        layout.addSpacing(8)
        powered = label('    LORDVAULT v2.0', 'muted')
        powered.setStyleSheet('font-size: 10px; color: #52525b;')
        layout.addWidget(powered)
        self.indicator = QFrame(self)
        self.indicator.setStyleSheet(f'background: {ACCENT_MAP.get("Overview", "#38bdf8")}; border-radius: 1.5px;')
        self.indicator.setFixedSize(3, 23)
        self.indicator.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.slide = QPropertyAnimation(self.indicator, b'pos', self)
        self.slide.setDuration(210)
        self.slide.setEasingCurve(QEasingCurve.Type.OutCubic)
        self.current = 'dashboard'

    def select(self, key):
        self.current = key
        for name, button in self.buttons.items():
            button.selected = name == key
            button.update()
        button = self.buttons[key]
        # Update indicator color to match the selected button's accent
        self.indicator.setStyleSheet(f'background: {button.accent}; border-radius: 1.5px;')
        end = QPoint(5, button.y() + (button.height() - 23) // 2)
        self.slide.stop()
        if self.motion:
            self.slide.setStartValue(self.indicator.pos())
            self.slide.setEndValue(end)
            self.slide.start()
        else:
            self.indicator.move(end)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        QTimer.singleShot(0, lambda: self.select(self.current))
