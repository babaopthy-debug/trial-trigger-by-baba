"""Shared desktop palette and typography. Premium dark theme with interaction accents."""

BG = '#000000'
SIDEBAR = '#050608'
PANEL = '#0c0e12'
PANEL_HOVER = '#12151c'
SURFACE = '#12141a'
BORDER = '#252a32'
BORDER_HOVER = '#383f4c'
TEXT = '#f5f7fa'
MUTED = '#8f98a8'
STEEL = '#71717a'
ACCENT = '#5b8cff'
SUCCESS = '#43b581'
WARNING = '#d6a84b'
ERROR = '#d95c5c'
DISABLED = '#666d78'

# Legacy aliases pointing to refined theme tones
PURPLE = ACCENT
CYAN = ACCENT
PINK = ACCENT

STYLESHEET = '''
QWidget { color: #f5f7fa; font-family: "Segoe UI", system-ui, sans-serif; font-size: 13px; }
QMainWindow, QWidget#root, QWidget#page { background: #000000; }
QLabel { background: transparent; }
QFrame#panel { background: #0c0e12; border: 1px solid #252d3b; border-radius: 8px; }
QFrame#sidebar { background: #050608; border-right: 1px solid #1f2532; }
QFrame#header { background: #050608; border-bottom: 1px solid #1f2532; }
QFrame#titleBar { background: #050608; border-bottom: 1px solid #1f2532; }
QFrame#statusPill { background: #0c0e12; border: 1px solid #1f2532; border-radius: 4px; }
QWidget#root { border: 1.5px solid #ffffff; }
QLabel#eyebrow { color: #8f98a8; font: 10px "Cascadia Code", "Cascadia Mono", "Consolas"; letter-spacing: 1.5px; }
QLabel#muted { color: #8f98a8; }
QLabel#pageTitle { font-size: 22px; font-weight: 600; letter-spacing: -0.4px; color: #f5f7fa; }
QLabel#sectionTitle { font-size: 15px; font-weight: 600; letter-spacing: -0.2px; color: #f5f7fa; }
QLabel#accent { color: #5b8cff; }
QPushButton { background: #15181e; border: 1px solid #252a32; border-radius: 6px;
  padding: 8px 14px; font-weight: 500; color: #f5f7fa; }
QPushButton:hover { background: #1d212a; border-color: #383f4c; color: #ffffff; }
QPushButton:pressed { background: #111318; }
QPushButton:focus { border-color: #5b8cff; }
QPushButton:disabled { color: #666d78; background: #0e1014; border-color: #1a1d24; }
QPushButton#primary { background: #5b8cff; color: #090a0c; border: 1px solid #5b8cff; font-weight: 600; }
QPushButton#primary:hover { background: #709cff; border-color: #709cff; color: #090a0c; }
QPushButton#primary:pressed { background: #4878e6; }
QPushButton#primary:disabled { background: #1a2233; color: #42526e; border-color: #202b40; }
QPushButton#danger { color: #d95c5c; background: #1a1012; border: 1px solid #3b1c20; font-weight: 500; }
QPushButton#danger:hover { background: #26161a; border-color: #5c2c34; color: #fca5a5; }
QPushButton#danger:disabled { color: #666d78; background: #0e1014; border-color: #1a1d24; }
QPushButton#secondary { background: #15181e; border: 1px solid #252a32; color: #f5f7fa; }
QPushButton#secondary:hover { background: #1d212a; border-color: #383f4c; }
QLineEdit { background: #0c0e12; border: 1px solid #252a32; border-radius: 6px;
  padding: 7px 10px; color: #f5f7fa; selection-background-color: #27344f; selection-color: #ffffff; }
QLineEdit:focus { border-color: #5b8cff; background: #0f1218; }
QLineEdit:disabled { color: #666d78; background: #0a0c0f; }
QSpinBox { background: #0c0e12; border: 1px solid #252a32; border-radius: 6px;
  padding: 6px 10px; color: #f5f7fa; }
QSpinBox:focus { border-color: #5b8cff; background: #0f1218; }
QSpinBox:disabled { color: #666d78; background: #0a0c0f; }
QSpinBox::up-button, QSpinBox::down-button { width: 18px; background: #15181e; border: none; border-left: 1px solid #252a32; }
QSpinBox::up-button:hover, QSpinBox::down-button:hover { background: #222733; }
QPlainTextEdit { background: #000000; border: 1px solid #222226; border-radius: 8px; color: #b4b4be;
  font: 12px "Cascadia Code", "JetBrains Mono", "Consolas", monospace; padding: 10px 12px;
  selection-background-color: #27344f; selection-color: #ffffff; }
QScrollArea { border: none; background: transparent; }
QScrollBar:vertical { width: 6px; background: transparent; margin: 3px 0; }
QScrollBar::handle:vertical { background: #252a32; border-radius: 3px; min-height: 24px; }
QScrollBar::handle:vertical:hover { background: #383f4c; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: transparent; }
QScrollBar:horizontal { height: 6px; background: transparent; }
QScrollBar::handle:horizontal { background: #252a32; border-radius: 3px; min-width: 24px; }
QScrollBar::handle:horizontal:hover { background: #383f4c; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0; }
QToolTip { color: #f5f7fa; background: #15181e; border: 1px solid #252a32; padding: 5px 8px; font-size: 11px; }
QCheckBox { spacing: 8px; color: #8f98a8; font-size: 12px; }
QCheckBox::indicator { width: 14px; height: 14px; border: 1px solid #252a32;
  border-radius: 3px; background: #111318; }
QCheckBox::indicator:hover { border-color: #5b8cff; }
QCheckBox::indicator:checked { background: #5b8cff; border: 1px solid #5b8cff; }
QComboBox { background: #0c0e12; border: 1px solid #252a32; border-radius: 5px; padding: 5px 10px; color: #f5f7fa; }
QComboBox:hover { border-color: #383f4c; }
QComboBox:focus { border-color: #5b8cff; }
QComboBox QAbstractItemView { background: #111318; color: #f5f7fa; selection-background-color: #1e2638; border: 1px solid #252a32; }
QMessageBox { background: #111318; }
QSplitter::handle { background: #090a0c; height: 6px; width: 6px; }
'''
