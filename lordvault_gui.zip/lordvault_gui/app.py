"""Standalone desktop application; the existing launcher owns backend behavior."""

import argparse
import os
from pathlib import Path
import sys
import time

from PySide6.QtCore import QEasingCurve, QPropertyAnimation, Qt, QTimer
from PySide6.QtGui import QColor, QFont, QIcon, QKeySequence, QPainter, QPixmap, QShortcut
from PySide6.QtWidgets import (QApplication, QCheckBox, QFrame, QGraphicsOpacityEffect,
                               QHBoxLayout, QLineEdit, QMainWindow, QMessageBox,
                               QPushButton, QScrollArea, QStackedWidget, QVBoxLayout, QWidget)

import interface
from .components import (LordVaultButton, LordVaultHeader, LordVaultLogConsole,
                         LordVaultProgress, LordVaultSidebar, LordVaultTitleBar, label)
from .dashboard import LordVaultDashboard
from .pages import LordVaultConfigPage, LordVaultGuidePage, LordVaultOrbClaimerPage, LordVaultTokenManager
from .session import BackendSession
from .theme import CYAN, STYLESHEET

ROOT = Path(__file__).resolve().parents[1]


def application_icon():
    pixmap = QPixmap(64, 64)
    pixmap.fill(Qt.GlobalColor.transparent)
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    painter.setBrush(QColor('#121215'))
    painter.setPen(QColor('#3f3f46'))
    painter.drawRoundedRect(2, 2, 60, 60, 10, 10)
    painter.setPen(QColor('#f4f4f5'))
    painter.setFont(QFont('Segoe UI', 24, QFont.Weight.Bold))
    painter.drawText(pixmap.rect(), Qt.AlignmentFlag.AlignCenter, 'L')
    painter.end()
    return QIcon(pixmap)


class LordVaultWorkspace(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName('page')
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 18, 0, 0)
        layout.setSpacing(17)
        layout.addWidget(label('LORDVAULT // TERMINAL WORKSPACE', 'eyebrow'))
        heading = QHBoxLayout()
        heading.addWidget(label('Workspace', 'pageTitle'))
        heading.addStretch()
        self.launch = QPushButton('Launch LordVault')
        self.launch.setObjectName('primary')
        self.stop = QPushButton('Stop workspace')
        self.stop.setObjectName('danger')
        self.stop.setEnabled(False)
        heading.addWidget(self.launch)
        heading.addWidget(self.stop)
        layout.addLayout(heading)
        subtitle = label('Your live session, prompts and activity — in one place.', 'muted')
        layout.addWidget(subtitle)
        self.progress = LordVaultProgress()
        layout.addWidget(self.progress)
        self.console = LordVaultLogConsole('Session activity')
        layout.addWidget(self.console, 1)
        prompt_panel = QFrame()
        prompt_panel.setObjectName('panel')
        prompt_layout = QVBoxLayout(prompt_panel)
        prompt_layout.setContentsMargins(18, 15, 18, 16)
        prompt_layout.addWidget(label('WORKSPACE INPUT', 'eyebrow'))
        self.prompt = label('Launch your workspace to begin.', 'muted')
        self.prompt.setWordWrap(True)
        self.prompt.setTextFormat(Qt.TextFormat.PlainText)
        self.prompt.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        prompt_layout.addWidget(self.prompt)
        row = QHBoxLayout()
        self.input = QLineEdit()
        self.input.setAccessibleName('Workspace response')
        self.input.setPlaceholderText('Type a response and press Enter')
        self.input.setEnabled(False)
        self.send = QPushButton('Send')
        self.send.setObjectName('primary')
        self.send.setEnabled(False)
        row.addWidget(self.input, 1)
        row.addWidget(self.send)
        prompt_layout.addLayout(row)
        bottom = QHBoxLayout()
        self.mask = QCheckBox('Hide input')
        self.mask.toggled.connect(lambda checked: self.input.setEchoMode(
            QLineEdit.EchoMode.Password if checked else QLineEdit.EchoMode.Normal))
        bottom.addWidget(self.mask)
        bottom.addStretch()
        bottom.addWidget(label('Enter sends your response, including an empty line.', 'muted'))
        prompt_layout.addLayout(bottom)
        layout.addWidget(prompt_panel)


class LordVaultApp(QMainWindow):
    def __init__(self, *, motion=True, session=None):
        super().__init__()
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Window)
        self.setWindowTitle('LORDVAULT | Control Center')
        self.setWindowIcon(application_icon())
        self.resize(1000, 640)
        self.setMinimumSize(840, 540)
        self.setMouseTracking(True)
        self.motion = motion
        self._closing = False
        self._state = 'stopped'
        self._dots = 0
        self.session = session or BackendSession(ROOT, self)
        root = QWidget()
        root.setObjectName('root')
        root.setMouseTracking(True)
        self.setCentralWidget(root)

        root_layout = QVBoxLayout(root)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)

        # Custom top title bar spanning across the entire window
        self.titlebar = LordVaultTitleBar(self)
        self.header = self.titlebar  # Backwards-compatible handle for header.state
        root_layout.addWidget(self.titlebar)

        # Main body container
        main_body = QWidget()
        main_body.setObjectName('mainBody')
        main_body.setMouseTracking(True)
        body_layout = QHBoxLayout(main_body)
        body_layout.setContentsMargins(0, 0, 0, 0)
        body_layout.setSpacing(0)

        self.sidebar = LordVaultSidebar()
        self.sidebar.selected.connect(self.navigate)
        body_layout.addWidget(self.sidebar)

        right = QVBoxLayout()
        right.setSpacing(0)
        self.stack = QStackedWidget()
        self.stack.setContentsMargins(18, 6, 18, 14)
        self.dashboard = LordVaultDashboard()
        self.dashboard.activated.connect(self.navigate)
        self.workspace = LordVaultWorkspace()
        self.tokens = LordVaultTokenManager()
        self.config = LordVaultConfigPage()
        self.guide = LordVaultGuidePage()
        self.orb_claimer = LordVaultOrbClaimerPage()
        self.pages = {'dashboard': self.dashboard, 'workspace': self.workspace,
                      'tokens': self.tokens, 'config': self.config,
                      'orb_claimer': self.orb_claimer, 'guide': self.guide}
        self.wrappers = {}
        for key, page in self.pages.items():
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setFrameShape(QFrame.Shape.NoFrame)
            scroll.setWidget(page)
            self.stack.addWidget(scroll)
            self.wrappers[key] = scroll
        right.addWidget(self.stack, 1)
        body_layout.addLayout(right, 1)
        root_layout.addWidget(main_body, 1)
        self.fade_effect = QGraphicsOpacityEffect(self.stack)
        self.stack.setGraphicsEffect(self.fade_effect)
        self.fade = QPropertyAnimation(self.fade_effect, b'opacity', self)
        self.fade.setDuration(220)
        self.fade.setEasingCurve(QEasingCurve.Type.OutCubic)
        self.sidebar.motion_changed.connect(self.set_motion)
        self.workspace.launch.clicked.connect(self.launch_workspace)
        self.workspace.stop.clicked.connect(self.stop_workspace)
        self.workspace.send.clicked.connect(self.send_input)
        self.workspace.input.returnPressed.connect(self.send_input)
        for page in (self.tokens, self.config, self.guide, self.orb_claimer):
            page.activity.connect(self.log)
        self.config.saved.connect(lambda: self.refresh(announce=True, skip_config=True))
        self.guide.launchRequested.connect(self.launch_workspace)
        self.orb_claimer.launchRequested.connect(self.launch_workspace)
        self.orb_claimer.stopRequested.connect(self.stop_workspace)
        self.session.output.connect(self.handle_output)
        self.session.prompt.connect(self.handle_prompt)
        self.session.state_changed.connect(self.handle_state)
        self.session.finished.connect(self.handle_finished)
        self.session.error.connect(lambda text: self.log('ERROR', text))
        self.session.progress.connect(self.handle_progress)
        self.shortcuts = []
        for index, key in enumerate(('launch', 'tokens', 'config', 'guide', 'exit'), 1):
            shortcut = QShortcut(QKeySequence(f'Alt+{index}'), self)
            shortcut.activated.connect(lambda k=key: self.navigate(k))
            self.shortcuts.append(shortcut)
        for sequence, action in [('Ctrl+R', lambda: self.refresh(True)), ('Ctrl+1', lambda: self.navigate('dashboard'))]:
            shortcut = QShortcut(QKeySequence(sequence), self)
            shortcut.activated.connect(action)
            self.shortcuts.append(shortcut)
        self.refresh_timer = QTimer(self)
        self.refresh_timer.setInterval(4000)
        self.refresh_timer.timeout.connect(self.refresh)
        self.refresh_timer.start()
        self.status_timer = QTimer(self)
        self.status_timer.setInterval(500)
        self.status_timer.timeout.connect(self.animate_status)
        self.status_timer.start()
        self.set_motion(motion)
        self.sidebar.motion_check.setChecked(motion)
        self.refresh()
        self.log('SYSTEM', 'LORDVAULT Control Center initialized.')
        self.log('INFO', 'Workspace counts and settings loaded from local files.')
        self.log('SYSTEM', 'Choose Launch LordVault when you are ready.')
        QTimer.singleShot(0, lambda: self.navigate('dashboard'))

    def showEvent(self, event):
        super().showEvent(event)
        if os.name == 'nt':
            try:
                import ctypes
                dark = ctypes.c_int(1)
                ctypes.windll.dwmapi.DwmSetWindowAttribute(
                    int(self.winId()), 20, ctypes.byref(dark), ctypes.sizeof(dark))
                class MARGINS(ctypes.Structure):
                    _fields_ = [('cxLeftWidth', ctypes.c_int),
                                ('cxRightWidth', ctypes.c_int),
                                ('cyTopHeight', ctypes.c_int),
                                ('cyBottomHeight', ctypes.c_int)]
                margins = MARGINS(1, 1, 1, 1)
                ctypes.windll.dwmapi.DwmExtendFrameIntoClientArea(int(self.winId()), ctypes.byref(margins))
            except (AttributeError, OSError):
                pass

    def changeEvent(self, event):
        if event.type() == event.Type.WindowStateChange:
            self.titlebar.update_maximize_icon(self.isMaximized())
        super().changeEvent(event)

    def mousePressEvent(self, event):
        if not self.isMaximized() and event.button() == Qt.MouseButton.LeftButton:
            edge = self._detect_edge(event.pos())
            if edge is not None:
                if self.windowHandle() and self.windowHandle().startSystemResize(edge):
                    return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if not self.isMaximized():
            edge = self._detect_edge(event.pos())
            self._update_cursor(edge)
        super().mouseMoveEvent(event)

    def _detect_edge(self, pos):
        margin = 6
        x, y = pos.x(), pos.y()
        w, h = self.width(), self.height()
        edges = 0
        if x <= margin:
            edges |= Qt.Edge.LeftEdge.value
        elif x >= w - margin:
            edges |= Qt.Edge.RightEdge.value
        if y <= margin:
            edges |= Qt.Edge.TopEdge.value
        elif y >= h - margin:
            edges |= Qt.Edge.BottomEdge.value
        if edges:
            return Qt.Edge(edges)
        return None

    def _update_cursor(self, edge):
        if edge is None:
            self.unsetCursor()
            return
        left = bool(edge.value & Qt.Edge.LeftEdge.value)
        right = bool(edge.value & Qt.Edge.RightEdge.value)
        top = bool(edge.value & Qt.Edge.TopEdge.value)
        bottom = bool(edge.value & Qt.Edge.BottomEdge.value)
        if (top and left) or (bottom and right):
            self.setCursor(Qt.CursorShape.SizeFDiagCursor)
        elif (top and right) or (bottom and left):
            self.setCursor(Qt.CursorShape.SizeBDiagCursor)
        elif left or right:
            self.setCursor(Qt.CursorShape.SizeHorCursor)
        elif top or bottom:
            self.setCursor(Qt.CursorShape.SizeVerCursor)

    def navigate(self, key):
        if key == 'exit':
            self.close()
            return
        if key == 'launch':
            self.launch_workspace()
            return
        if key not in self.pages:
            return
        self.fade.stop()
        self.stack.setCurrentWidget(self.wrappers[key])
        self.sidebar.select(key)
        if key in ('tokens', 'config', 'guide', 'orb_claimer'):
            self.pages[key].refresh()
        if self.motion:
            self.fade.setStartValue(.25)
            self.fade.setEndValue(1.)
            self.fade.start()
        else:
            self.fade_effect.setOpacity(1.)

    def set_motion(self, enabled):
        self.motion = enabled
        self.titlebar.set_motion(enabled)
        self.sidebar.motion = enabled
        self.dashboard.set_motion(enabled)
        self.workspace.progress.motion = enabled
        if self.workspace.progress.busy and enabled:
            self.workspace.progress.timer.start()
        else:
            self.workspace.progress.timer.stop()
        self.workspace.progress.update()
        for button in self.findChildren(LordVaultButton):
            button.motion = enabled
        from .components import LordVaultToggle
        for toggle in self.findChildren(LordVaultToggle):
            toggle.motion = enabled
        if not enabled:
            self.fade.stop()
            self.fade_effect.setOpacity(1)
            self.sidebar.slide.stop()
            self.sidebar.select(self.sidebar.current)

    def refresh(self, announce=False, skip_config=False):
        self.dashboard.refresh(interface.snapshot())
        if announce:
            self.tokens.refresh()
            if not skip_config:
                self.config.refresh()
            self.log('INFO', 'Workspace counts and settings refreshed.')

    def log(self, level, text):
        self.dashboard.console.add(level, text)
        self.workspace.console.add(level, text)

    def handle_output(self, text):
        self.dashboard.console.feed(text)
        self.workspace.console.feed(text)

    def handle_prompt(self, prompt):
        if prompt:
            self.workspace.prompt.setText(prompt)
            self.header.state.setText('●  AWAITING INPUT')
            self.header.state.setStyleSheet('color: #5b8cff; font-weight: 600; font-size: 9px; letter-spacing: 1px;')
            self.workspace.input.setEnabled(True)
            self.workspace.send.setEnabled(True)
            lowered = prompt.lower()
            self.workspace.mask.setChecked(any(word in lowered for word in ('password', 'secret', 'token')))
            if self.stack.currentWidget() is self.wrappers['workspace']:
                self.workspace.input.setFocus()
        else:
            self.workspace.prompt.setText('Response sent. Waiting for workspace…')

    def handle_progress(self, current, total):
        self.dashboard.progress.set_progress(current, total)
        self.workspace.progress.set_progress(current, total)

    def launch_workspace(self):
        self.navigate('workspace')
        if not self.session.is_running:
            self.session.start()

    def send_input(self):
        if not self.session.is_running or not self.workspace.input.isEnabled():
            return
        value = self.workspace.input.text()
        self.session.send_input(value)
        self.workspace.input.clear()
        # User responses may contain credentials: never echo them into logs.

    def stop_workspace(self):
        if self._state == 'stopping':
            answer = QMessageBox.question(self, 'Force stop workspace?',
                'The workspace is still shutting down. Force stop it and its child processes?',
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No)
            if answer == QMessageBox.StandardButton.Yes:
                self.session.force_stop()
        else:
            self.session.stop()

    def handle_state(self, state):
        self._state = state
        running = state != 'stopped'
        self.workspace.launch.setEnabled(not running)
        self.workspace.stop.setEnabled(running)
        self.workspace.stop.setText('Force stop…' if state == 'stopping' else 'Stop workspace')
        self.workspace.input.setEnabled(state == 'running')
        self.workspace.send.setEnabled(state == 'running')
        self.dashboard.progress.set_busy(state in ('starting', 'running', 'stopping'))
        self.workspace.progress.set_busy(state in ('starting', 'running', 'stopping'))
        self.orb_claimer.set_state(state)
        titles = {'starting': 'Starting workspace', 'running': 'Workspace running',
                  'stopping': 'Stopping workspace', 'stopped': 'Workspace idle'}
        colors = {'starting': '#d6a84b', 'running': '#43b581', 'stopping': '#d6a84b', 'stopped': '#8f98a8'}
        status_color = colors.get(state, '#8f98a8')
        self.header.state.setText('●  ' + titles.get(state, state).upper())
        self.header.state.setStyleSheet(f'color: {status_color}; font-weight: 600; font-size: 9px; letter-spacing: 1px;')
        self.dashboard.status.setText('●  ' + titles.get(state, state))
        self.dashboard.status.setStyleSheet(f'color: {status_color}; font-size: 11px;')
        if state == 'running':
            self.workspace.prompt.setText('Session active. Respond below when the workspace asks for input.')
        elif state == 'stopped':
            self.workspace.prompt.setText('Session ended. Launch LordVault to begin again.')
            self.workspace.input.clear()
        self.log('SYSTEM', titles.get(state, state) + '.')

    def animate_status(self):
        if self._state in ('starting', 'running', 'stopping'):
            self._dots = (self._dots + 1) % 4
            text = {'starting': 'Starting workspace', 'running': 'Workspace running',
                    'stopping': 'Stopping workspace'}[self._state]
            self.dashboard.status.setText('●  ' + text + ('.' * self._dots if self.motion else ''))

    def handle_finished(self, code):
        self.log('SYSTEM' if code == 0 else 'WARNING', f'Workspace session ended (exit {code}).')
        self.refresh()
        if self._closing:
            QTimer.singleShot(0, self.close)

    def closeEvent(self, event):
        if self.session.is_running:
            if not self._closing:
                answer = QMessageBox.question(self, 'Close LORDVAULT?',
                    'A workspace session is active. Stop it and close LORDVAULT?',
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.No)
                if answer != QMessageBox.StandardButton.Yes:
                    event.ignore()
                    return
                self._closing = True
                self.session.stop()
                self.navigate('workspace')
            event.ignore()
            return
        self.session.close()
        event.accept()


def run(argv=None):
    parser = argparse.ArgumentParser(description='LORDVAULT Control Center desktop')
    parser.add_argument('--no-animation', action='store_true', help='Reduce interface motion')
    parser.add_argument('--smoke-test', action='store_true', help='Open and close the UI without launching the backend')
    parser.add_argument('--screenshot', type=Path, help='Save a desktop UI screenshot (backend stays idle)')
    args = parser.parse_args(argv)
    app = QApplication.instance() or QApplication(sys.argv[:1])
    app.setApplicationName('LORDVAULT Control Center')
    app.setOrganizationName('LordVault')
    app.setStyle('Fusion')
    app.setStyleSheet(STYLESHEET)
    app.setWindowIcon(application_icon())
    reduced = os.environ.get('LORDVAULT_REDUCED_MOTION', '').lower() in ('1', 'true', 'yes')
    window = LordVaultApp(motion=not (args.no_animation or reduced))
    screen = app.primaryScreen()
    if screen:
        available = screen.availableGeometry()
        window.resize(min(1000, available.width() - 40), min(640, available.height() - 40))
        window.move(available.center() - window.rect().center())
    window.show()
    app.aboutToQuit.connect(window.session.close)
    if args.screenshot:
        def capture():
            args.screenshot.parent.mkdir(parents=True, exist_ok=True)
            if not window.grab().save(str(args.screenshot)):
                raise RuntimeError(f'Could not save screenshot to {args.screenshot}')
        QTimer.singleShot(1100, capture)
    if args.smoke_test:
        QTimer.singleShot(1450, app.quit)
    return app.exec()
