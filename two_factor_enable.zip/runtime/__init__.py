# Clean binary package
