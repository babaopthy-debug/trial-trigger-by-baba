"""Build a browser preview from the real terminal renderer, using sample data."""

import html
import json
from pathlib import Path
import re
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import interface


def color(index):
    if index < 16:
        return ('#000000', '#800000', '#008000', '#808000', '#000080', '#800080',
                '#008080', '#c0c0c0', '#808080', '#ff0000', '#00ff00', '#ffff00',
                '#0000ff', '#ff00ff', '#00ffff', '#ffffff')[index]
    if index >= 232:
        value = 8 + (index - 232) * 10
        return '#{0:02x}{0:02x}{0:02x}'.format(value)
    index -= 16
    levels = (0, 95, 135, 175, 215, 255)
    return '#{:02x}{:02x}{:02x}'.format(levels[index // 36], levels[(index // 6) % 6], levels[index % 6])


def spans(line):
    style = {}
    result = []
    for part in re.split(r'(\x1b\[[0-9;]*m)', line):
        if part.startswith('\x1b['):
            codes = [int(item) for item in part[2:-1].split(';') if item] or [0]
            index = 0
            while index < len(codes):
                code = codes[index]
                if code == 0:
                    style = {}
                elif code == 1:
                    style['font-weight'] = '700'
                elif code in (38, 48) and codes[index + 1:index + 2] == [5]:
                    style['color' if code == 38 else 'background-color'] = color(codes[index + 2])
                    index += 2
                index += 1
        elif part:
            css = ';'.join(f'{key}:{value}' for key, value in style.items())
            result.append(f'<span style="{css}">{html.escape(part)}</span>')
    return ''.join(result)


sample = {'tokens': 128, 'orbs': 24, 'workers': 10, 'quests': True, 'proxy': False}
frames = {}
for columns, rows in ((80, 25), (100, 35), (40, 15)):
    frames[str(columns)] = [
        '\n'.join(spans(line) for line in interface.render_dashboard(
            sample, columns, rows, selected=selected, phase=phase,
            clock='12:48:06', motion=True))
        for selected in range(5) for phase in range(16)
    ]

page = '''<!doctype html><html lang="en"><meta charset="utf-8">
<title>LordVault · Terminal Preview</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#080c14;color:#c6cbdb;font:14px system-ui;padding:38px}
header{display:flex;align-items:center;justify-content:space-between;max-width:1120px;margin:0 auto 24px}
h1{margin:0;color:#fafafa;font-size:20px;letter-spacing:-.5px}small{color:#8c95aa}
button{border:1px solid #30374b;border-radius:7px;padding:8px 12px;background:#151d2d;color:#bbc6dc;cursor:pointer;margin-left:6px}
button.active{border-color:#af87ff;color:#dfcaff;background:#29203c}
section{width:max-content;max-width:100%;margin:auto;border:1px solid #303747;border-radius:12px;overflow:hidden;box-shadow:0 20px 80px #0008;background:#0c1019}
.titlebar{padding:13px 17px;color:#9ca7bf;font-size:12px;background:#131a27;border-bottom:1px solid #242d40;display:flex;gap:8px;align-items:center}
.dot{width:9px;height:9px;border-radius:50%;background:#6c577e}.dot:nth-child(2){background:#505d79}.dot:nth-child(3){background:#447277}.name{margin-left:8px}
pre{font-family:Consolas,'Cascadia Mono',monospace;font-size:clamp(8px,1.35vw,15px);line-height:1.5;margin:0;padding:22px 10px 26px;min-height:375px;white-space:pre}
footer{max-width:1120px;margin:22px auto;color:#737f98;font-size:12px}kbd{color:#b2c3df}
</style>
<header><div><h1>LordVault</h1><small>Terminal UI · sample data</small></div><nav>
<button onclick="chooseSize(80)" id="size80" class="active">80 × 25</button>
<button onclick="chooseSize(100)" id="size100">100 × 35</button>
<button onclick="chooseSize(40)" id="size40">40 × 15</button>
<button onclick="toggleMotion()" id="motion">Motion on</button></nav></header>
<section><div class="titlebar"><i class="dot"></i><i class="dot"></i><i class="dot"></i><span class="name">LordVault | Control Center</span></div><pre id="screen"></pre></section>
<footer>Preview rendered from interface.py. Use <kbd>↑ ↓</kbd> to change selection and <kbd>M</kbd> to toggle motion. Sample values only; actions are disabled.</footer>
<script>
const frames=__FRAMES__;let size=80,phase=0,selected=0,motion=true;
function draw(){let frame=frames[size][selected*16+phase];document.getElementById('screen').innerHTML=motion?frame:frame.replaceAll('Motion ON','Motion OFF')}
function chooseSize(n){size=n;document.querySelectorAll('[id^=size]').forEach(b=>b.classList.toggle('active',b.id==='size'+n));draw()}
function toggleMotion(){motion=!motion;document.getElementById('motion').textContent='Motion '+(motion?'on':'off');draw()}
document.addEventListener('keydown',e=>{if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();selected=(selected+(e.key==='ArrowDown'?1:4))%5;draw()}if(e.key.toLowerCase()==='m')toggleMotion()});
setInterval(()=>{if(motion){phase=(phase+1)%16;draw()}},250);draw();
</script></html>'''

destination = Path(__file__).with_name('lordvault-preview.html')
destination.write_text(page.replace('__FRAMES__', json.dumps(frames)), encoding='utf-8')
print(destination)
