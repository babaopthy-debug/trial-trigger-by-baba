$ErrorActionPreference = 'Stop'
$sourceFolder = Join-Path $PSScriptRoot 'matched'
New-Item -ItemType Directory -Path $sourceFolder -Force | Out-Null
$assets = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'assets.txt')
$assets | Where-Object { $_ -match '^/assets/[A-Za-z0-9._-]+\.js$' -and $_ -notmatch '/web\.' } | ForEach-Object -Parallel {
    try {
        $assetPath = $_
        $response = Invoke-WebRequest -Uri ('https://discord.com' + $assetPath) -UseBasicParsing -TimeoutSec 20
        $source = [string]$response.Content
        $patterns = @('VIRTUAL_CURRENCY_SKU_REDEEM', 'QUESTS_CLAIM_REWARD', 'orb_quantity')
        $hits = @($patterns | Where-Object { $source.Contains($_) })
        if ($hits.Count -gt 0) {
            $assetFile = [IO.Path]::GetFileName($assetPath)
            $destination = Join-Path $using:sourceFolder $assetFile
            [IO.File]::WriteAllText($destination, $source)
            [PSCustomObject]@{ Asset = $assetPath; Bytes = $source.Length; Matches = ($hits -join ',') }
        }
    } catch {
        [PSCustomObject]@{ Asset = $_.TargetObject; Error = $_.Exception.Message }
    }
} -ThrottleLimit 8 | Format-Table -AutoSize
