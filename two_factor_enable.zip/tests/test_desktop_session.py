"""Offline process-transport checks. No workspace modules or token files load."""

from __future__ import annotations

import ctypes
import os
from pathlib import Path
import sys
import tempfile
import time
import unittest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtCore import QCoreApplication
from lordvault_gui.session import BackendSession, _AnsiDecoder


class SessionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QCoreApplication.instance() or QCoreApplication([])

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.sessions = []

    def tearDown(self):
        for session in self.sessions:
            session.close()
        self.app.processEvents()
        self.temp.cleanup()

    def wait_for(self, predicate, timeout=10):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            self.app.processEvents()
            if predicate():
                return
            time.sleep(0.01)
        self.fail("Timed out waiting for synthetic backend")

    def session(self, script):
        fixture = self.root / f"fixture_{len(self.sessions)}.py"
        fixture.write_text(script, encoding="utf-8")
        session = BackendSession(self.root, command=[sys.executable, "-u", str(fixture)])
        self.sessions.append(session)
        return session

    def test_prompt_unicode_input_and_return_code(self):
        session = self.session(
            "import os, sys\n"
            "print('PIPE=' + str(sys.stdin.isatty()))\n"
            "print('BACKEND=' + os.environ.get('LORDVAULT_BACKEND', 'missing'))\n"
            "answer = input('\\033[35m╰─ ❯ Skip quest? [ y / n ] ❯ \\033[0m')\n"
            "print('ANSWER=' + answer)\n"
            "print('VERIFY [━━] 2/2 100%')\n"
            "raise SystemExit(7)\n"
        )
        output, prompts, errors, codes, progress = [], [], [], [], []
        session.output.connect(output.append)
        session.prompt.connect(prompts.append)
        session.error.connect(errors.append)
        session.finished.connect(codes.append)
        session.progress.connect(lambda current, total: progress.append((current, total)))
        session.start()
        self.wait_for(lambda: any("Skip quest" in value for value in prompts))
        self.assertIn("PIPE=False", "".join(output))
        self.assertIn("BACKEND=1", "".join(output))
        self.assertNotIn("\x1b", "".join(output))
        self.assertTrue(session.send_input("n"))
        self.wait_for(lambda: bool(codes))
        self.assertEqual(codes, [7])
        self.assertEqual(errors, [])
        self.assertIn("ANSWER=n", "".join(output))
        self.assertIn((2, 2), progress)
        self.assertFalse(session.is_running)

    def test_real_interrupt_reaches_python_cleanup(self):
        session = self.session(
            "import time\n"
            "print('READY')\n"
            "try:\n"
            "    while True: time.sleep(.1)\n"
            "except KeyboardInterrupt:\n"
            "    print('CLEANUP_COMPLETE')\n"
        )
        output, errors, codes = [], [], []
        session.output.connect(output.append)
        session.error.connect(errors.append)
        session.finished.connect(codes.append)
        session.start()
        self.wait_for(lambda: "READY" in "".join(output))
        session.stop()
        self.wait_for(lambda: bool(codes))
        self.assertIn("CLEANUP_COMPLETE", "".join(output))
        self.assertEqual(codes, [0])
        self.assertEqual(errors, [])

    def test_restart_is_clean_and_empty_input_is_preserved(self):
        session = self.session("print('WAIT'); value = input('Press Enter to exit... '); print('LEN=' + str(len(value)))\n")
        output, prompts, codes = [], [], []
        session.output.connect(output.append)
        session.prompt.connect(prompts.append)
        session.finished.connect(codes.append)
        for expected in (1, 2):
            prompts.clear()
            session.start()
            self.wait_for(lambda: any("Press Enter" in value for value in prompts))
            self.assertTrue(session.send_input(""))
            self.wait_for(lambda: len(codes) == expected)
        self.assertEqual(codes, [0, 0])
        self.assertEqual("".join(output).count("LEN=0"), 2)

    @unittest.skipUnless(os.name == "nt", "Windows job object test")
    def test_natural_exit_reaps_descendants_with_inherited_stdout(self):
        session = self.session(
            "import subprocess, sys\n"
            "child = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(60)'])\n"
            "print('DESCENDANT=' + str(child.pid))\n"
        )
        output, codes, errors = [], [], []
        session.output.connect(output.append)
        session.finished.connect(codes.append)
        session.error.connect(errors.append)
        session.start()
        self.wait_for(lambda: bool(codes))
        pid = int("".join(output).split("DESCENDANT=")[1].split()[0])
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.OpenProcess.restype = ctypes.c_void_p
        kernel.OpenProcess.argtypes = [ctypes.c_ulong, ctypes.c_int, ctypes.c_ulong]
        kernel.GetExitCodeProcess.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ulong)]
        kernel.CloseHandle.argtypes = [ctypes.c_void_p]
        handle = kernel.OpenProcess(0x1000, False, pid)
        if handle:
            code = ctypes.c_ulong()
            kernel.GetExitCodeProcess(handle, ctypes.byref(code))
            kernel.CloseHandle(handle)
            self.assertNotEqual(code.value, 259, "Descendant still running")
        self.assertEqual(errors, [])
        self.assertEqual(codes, [0])

    def test_force_close_reaps_helper(self):
        session = self.session("import time; print('READY'); time.sleep(60)\n")
        output = []
        session.output.connect(output.append)
        session.start()
        self.wait_for(lambda: "READY" in "".join(output))
        process = session._process
        session.close()
        self.assertIsNotNone(process.poll())
        self.wait_for(lambda: not session.is_running)


class EscapeDecoderTests(unittest.TestCase):
    def test_partial_escapes_and_title_sequence(self):
        decoder = _AnsiDecoder()
        self.assertEqual(decoder.feed("one\x1b[3"), "one")
        self.assertEqual(decoder.feed("5mtwo\x1b]0;Title"), "two")
        self.assertEqual(decoder.feed("\x07three\x1b[0m"), "three")


if __name__ == "__main__":
    unittest.main()
