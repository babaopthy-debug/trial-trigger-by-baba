"""Offline desktop checks. Every workspace read is replaced with synthetic data."""

import os
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from PySide6.QtWidgets import QApplication, QLabel, QLineEdit

import interface
from lordvault_gui.components import LordVaultLogConsole, LordVaultProgress
from lordvault_gui.pages import LordVaultConfigPage, LordVaultTokenManager
from lordvault_gui.theme import STYLESHEET


class DesktopTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])
        cls.app.setStyleSheet(STYLESHEET)

    def setUp(self):
        self.widgets = []
        self.enterContext(patch.object(interface, "_read_lines", return_value=[
            "synthetic-plain-token", "fake-email:fake-password:synthetic-combo-token",
        ]))
        self.enterContext(patch.object(interface, "get_orb_token_count", return_value=1))
        self.enterContext(patch.object(interface, "load_config", return_value={
            "max_workers": 10,
            "use_proxy": False,
            "quest_completer": {"enabled": True, "quest_ids": ["synthetic-quest"]},
            "setup": {"invite": "private-synthetic-invite", "voice_channel_id": "private-synthetic-id"},
        }))

    def tearDown(self):
        for widget in self.widgets:
            widget.close()
            widget.deleteLater()
        self.app.processEvents()

    def keep(self, widget):
        self.widgets.append(widget)
        return widget

    def test_inventory_preserves_format_counts_without_displaying_credentials(self):
        page = self.keep(LordVaultTokenManager())
        self.assertEqual({key: field.text() for key, field in page.counts.items()}, {
            "total": "2", "combo": "1", "plain": "1", "orbs": "1",
        })
        visible = "\n".join(label.text() for label in page.findChildren(QLabel))
        self.assertNotIn("synthetic-plain-token", visible)
        self.assertNotIn("fake-password", visible)
        self.assertNotIn("synthetic-combo-token", visible)

    def test_config_preserves_flags_defaults_and_masks_private_setup(self):
        page = self.keep(LordVaultConfigPage())
        self.assertEqual(page.fields["workers"].text(), "10")
        self.assertIn("OFF", page.fields["proxy"].text())
        self.assertIn("ON", page.fields["quest"].text())
        self.assertIn("ON", page.fields["buyer"].text())
        self.assertEqual(page.fields["sku"].text(), interface.DEFAULT_ORBS_BUYER_SKU)
        self.assertEqual(page.fields["quest_ids"].text(), "synthetic-quest")
        visible = "\n".join(label.text() for label in page.findChildren(QLabel))
        self.assertNotIn("private-synthetic-invite", visible)
        self.assertNotIn("private-synthetic-id", visible)

    def test_live_log_normalizes_levels_filters_and_keeps_text_literal(self):
        log = self.keep(LordVaultLogConsole())
        log.feed("\x1b[32m04:44:29 INFO Validating tokens...\x1b[0m\n")
        log.feed("[04:44:36] OK 20/20 tokens validated\n")
        log.feed("04:44:37 OK Workspace ready\n")
        log.add("WARN", "<b>literal warning</b>")
        log.add("ERR", "Synthetic failure")
        log.add("DBG", "Synthetic diagnostic")
        log.flush_pending()
        self.assertEqual([item[1] for item in log.records], [
            "INFO", "VERIFY", "SUCCESS", "WARNING", "ERROR", "SYSTEM",
        ])
        self.assertIn("<b>literal warning</b>", log.text.toPlainText())
        log.filter.setCurrentText("ERROR")
        self.assertIn("Synthetic failure", log.text.toPlainText())
        self.assertNotIn("Workspace ready", log.text.toPlainText())
        log.filter.setCurrentText("All events")
        self.assertIn("Workspace ready", log.text.toPlainText())
        log.clear()
        self.assertFalse(log.records)
        self.assertEqual(log.text.toPlainText(), "")

    def test_live_log_error_parsing_and_color_mapping(self):
        log = self.keep(LordVaultLogConsole())
        # Test standalone timestamp followed by ERR line
        log.feed("08:12:05\nERR Invalid server invite link or code\n")
        log.feed("WARN Low balance warning\n")
        log.feed("08:12:06  OK Connection established\n")
        # Test SYSTEM logs with Login OK and SUCCESS, and pipe noise
        log.feed("[09:50:07] SYSTEM   │\n")
        log.feed("[09:50:07] SYSTEM   Login OK -> MTU0OTY4NTU3NTcyNjky...\n")
        log.feed("[09:50:07] SYSTEM   SUCCESS\n")
        log.flush_pending()

        self.assertEqual(len(log.records), 5)
        self.assertEqual(log.records[0], ("08:12:05", "ERROR", "Invalid server invite link or code"))
        self.assertEqual(log.records[1][1], "WARNING")
        self.assertEqual(log.records[2], ("08:12:06", "SUCCESS", "Connection established"))
        self.assertEqual(log.records[3], ("09:50:07", "SUCCESS", "Login OK -> MTU0OTY4NTU3NTcyNjky..."))
        self.assertEqual(log.records[4], ("09:50:07", "SUCCESS", "SUCCESS"))

        # Verify colors are distinct
        self.assertNotEqual(log.COLORS["ERROR"], log.COLORS["SUCCESS"])
        self.assertNotEqual(log.COLORS["WARNING"], log.COLORS["ERROR"])

    def test_progress_is_idle_until_started_and_uses_reported_fraction(self):
        progress = self.keep(LordVaultProgress())
        progress.motion = False
        self.assertFalse(progress.busy)
        self.assertEqual(progress.value, 0)
        progress.set_busy(True)
        self.assertTrue(progress.busy)
        self.assertFalse(progress.timer.isActive())
        progress.set_progress(7, 20)
        self.assertFalse(progress.busy)
        self.assertAlmostEqual(progress.value, .35)
        progress.set_busy(False)
        self.assertEqual(progress.value, 0)

    def test_config_interactive_editing_and_reset(self):
        page = self.keep(LordVaultConfigPage())
        self.assertFalse(page.save_btn.isEnabled())
        self.assertFalse(page.reset_btn.isEnabled())
        self.assertIn("Synced", page.status_badge.text())

        # Toggle proxy switch
        page.fields["proxy"].toggle.click()
        self.assertTrue(page.fields["proxy"].isChecked())
        self.assertTrue(page.save_btn.isEnabled())
        self.assertTrue(page.reset_btn.isEnabled())
        self.assertIn("Unsaved", page.status_badge.text())

        # Reset reverts back to baseline
        page.reset_btn.click()
        self.assertFalse(page.fields["proxy"].isChecked())
        self.assertFalse(page.save_btn.isEnabled())
        self.assertIn("reverted", page.status_badge.text().lower())

        # Test masking toggle — starts masked (Password), first click reveals (Normal), second re-masks
        self.assertEqual(page.fields["invite"].echoMode(), QLineEdit.EchoMode.Password)
        page.mask_switch.toggle.click()   # show private values
        self.assertEqual(page.fields["invite"].echoMode(), QLineEdit.EchoMode.Normal)
        page.mask_switch.toggle.click()   # hide again
        self.assertEqual(page.fields["invite"].echoMode(), QLineEdit.EchoMode.Password)


    def test_config_validation_and_safe_saving(self):
        import json
        import tempfile
        page = self.keep(LordVaultConfigPage())
        # Test required SKU validation when buyer is enabled
        page.fields["buyer"].setChecked(True)
        page.fields["sku"].setText("")
        page.save_btn.click()
        self.assertIn("Item SKU is required", page.status_badge.text())

        # Valid save
        page.fields["sku"].setText("1342211853484429445")
        page.fields["workers"].setValue(15)
        page.fields["proxy"].toggle.click()
        saved_signals = []
        page.saved.connect(lambda: saved_signals.append(True))

        with tempfile.TemporaryDirectory() as tmpdir:
            input_dir = Path(tmpdir) / "input"
            input_dir.mkdir(parents=True, exist_ok=True)
            cfg_file = input_dir / "config.json"
            cfg_file.write_text(json.dumps({"bot_token": "keep_this_key", "use_proxy": False}), encoding="utf-8")
            with patch("lordvault_gui.pages.interface.__file__", str(Path(tmpdir) / "interface.py")):
                page.save_btn.click()
                self.assertIn("saved", page.status_badge.text().lower())
                self.assertEqual(len(saved_signals), 1)
                data = json.loads(cfg_file.read_text(encoding="utf-8"))
                self.assertEqual(data["bot_token"], "keep_this_key")
                self.assertEqual(data["max_workers"], 15)
                self.assertTrue(data["use_proxy"])

    def test_titlebar_components_and_status_transitions(self):
        from lordvault_gui.titlebar import LordVaultTitleBar, LordVaultBadge, LordVaultWindowButton
        bar = self.keep(LordVaultTitleBar())
        self.assertIsInstance(bar.badge, LordVaultBadge)
        # Brand is now LORD (cyan) + VAULT (rose) in separate colored spans
        brand_text = bar.brand_title.text()
        self.assertIn("LORD", brand_text)
        self.assertIn("VAULT", brand_text)
        self.assertIn("Control Center", bar.brand_title.text())
        self.assertIsInstance(bar.min_btn, LordVaultWindowButton)
        self.assertIsInstance(bar.max_btn, LordVaultWindowButton)
        self.assertIsInstance(bar.close_btn, LordVaultWindowButton)
        self.assertEqual(bar.state.text(), "WORKSPACE IDLE")

        # Status update
        bar.set_status("WORKSPACE RUNNING", "#43b581")
        self.assertEqual(bar.state.text(), "WORKSPACE RUNNING")
        self.assertIn("#43b581", bar.state.styleSheet())
        self.assertIn("#43b581", bar.dot.styleSheet())

        # Maximize/restore icon toggle
        bar.update_maximize_icon(True)
        self.assertEqual(bar.max_btn.icon_text, "❐")
        self.assertEqual(bar.max_btn.toolTip(), "Restore")
        bar.update_maximize_icon(False)
        self.assertEqual(bar.max_btn.icon_text, "□")
        self.assertEqual(bar.max_btn.toolTip(), "Maximize")

    def test_app_titlebar_integration_and_state_updates(self):
        from lordvault_gui.app import LordVaultApp
        win = self.keep(LordVaultApp(motion=False))
        self.assertIsNotNone(win.titlebar)
        self.assertIs(win.header, win.titlebar)

        # Test state handling updates titlebar status
        win.handle_state("running")
        self.assertIn("WORKSPACE RUNNING", win.titlebar.state.text())
        self.assertIn("#43b581", win.titlebar.dot.styleSheet())

        win.handle_prompt("Password:")
        self.assertIn("AWAITING INPUT", win.titlebar.state.text())
        self.assertIn("#5b8cff", win.titlebar.dot.styleSheet())

        win.handle_state("stopped")
        self.assertIn("WORKSPACE IDLE", win.titlebar.state.text())


if __name__ == "__main__":
    unittest.main()
