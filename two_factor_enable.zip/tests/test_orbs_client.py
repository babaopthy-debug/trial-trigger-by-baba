"""Client and display tests; every HTTP request and output write is mocked."""

import importlib.util
from pathlib import Path
import queue
import sys
import unittest
from unittest.mock import Mock, patch


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

spec = importlib.util.spec_from_file_location('orbs_client_under_test', ROOT / 'orb_claimer' / 'orb.py')
orb = importlib.util.module_from_spec(spec)
with patch('os.system'):
    spec.loader.exec_module(orb)

import interface


class OrbsClientTests(unittest.TestCase):
    def setUp(self):
        self.get = self.enterContext(patch.object(orb.requests, 'get'))
        self.post = self.enterContext(patch.object(orb.requests, 'post'))
        self.get.return_value.status_code = 200
        self.response = self.post.return_value
        self.response.status_code = 200
        self.response.json.return_value = {
            'success': True,
            'claimConfirmed': True,
            'purchase': {'status': 'purchased', 'skuId': '1342211853484429445'},
        }
        self.log = self.enterContext(patch.object(orb, 'log'))
        self.save = self.enterContext(patch.object(orb, 'save_output'))
        self.enterContext(patch.object(orb, 'TOKEN_QUEUE', queue.Queue()))

    def run_worker(self):
        orb.TOKEN_QUEUE.put('synthetic-test-token')
        orb.worker(1)
        self.assertEqual(orb.TOKEN_QUEUE.unfinished_tasks, 0)
        return [call.args[0] for call in self.save.call_args_list]

    def test_structured_success_and_extended_timeout(self):
        result = orb.send_to_api_result('synthetic-test-token')
        self.assertTrue(result['success'])
        self.assertTrue(result['claimConfirmed'])
        self.assertEqual(result['purchase']['status'], 'purchased')
        self.post.assert_called_once_with(
            orb.API_URL, json={'token': 'synthetic-test-token'}, timeout=360,
        )

    def test_http_200_requires_literal_success_true(self):
        for body in ({}, {'success': False}, {'success': 1}, {'success': 'true'}, [], None):
            with self.subTest(body=body):
                self.response.json.return_value = body
                self.assertFalse(orb.send_to_api_result('synthetic-test-token')['success'])

    def test_non_json_http_200_is_failure(self):
        self.response.json.side_effect = ValueError('not JSON')
        self.assertFalse(orb.send_to_api_result('synthetic-test-token')['success'])

    def test_http_failure_does_not_accept_success_field(self):
        self.response.status_code = 500
        result = orb.send_to_api_result('synthetic-test-token')
        self.assertFalse(result['success'])
        self.assertEqual(result['error'], 'HTTP 500')

    def test_invalid_token_does_not_call_claim_api(self):
        self.get.return_value.status_code = 401
        result = orb.send_to_api_result('synthetic-test-token')
        self.assertFalse(result['success'])
        self.post.assert_not_called()

    def test_legacy_tuple_interface_keeps_reward_code(self):
        self.response.json.return_value['rewardCode'] = 'sample-reward'
        self.assertEqual(orb.send_to_api('synthetic-test-token'), (True, 'sample-reward'))

    def test_legacy_tuple_interface_reports_failure(self):
        self.response.json.return_value = {'success': False, 'error': 'Claim not confirmed'}
        self.assertEqual(orb.send_to_api('synthetic-test-token'), (False, 'Claim not confirmed'))

    def test_purchase_without_confirmed_claim_is_unconfirmed(self):
        for confirmed in (False, None, 1, 'true'):
            with self.subTest(confirmed=confirmed):
                self.response.json.return_value['claimConfirmed'] = confirmed
                result = orb.send_to_api_result('synthetic-test-token')
                self.assertEqual(result['purchase']['status'], 'unconfirmed')

    def test_missing_or_unknown_purchase_status_is_unconfirmed(self):
        for purchase in (None, {}, [], {'status': 'success'}):
            with self.subTest(purchase=purchase):
                self.response.json.return_value['purchase'] = purchase
                result = orb.send_to_api_result('synthetic-test-token')
                self.assertEqual(result['purchase']['status'], 'unconfirmed')

    def test_confirmed_purchase_has_distinct_success_output(self):
        self.assertEqual(self.run_worker(), ['api_success.txt', 'orbs_buyer_success.txt'])

    def test_purchase_failure_does_not_overwrite_claim_success(self):
        self.response.json.return_value['purchase'] = {
            'status': 'failed', 'skuId': '1342211853484429445', 'error': 'Insufficient Orbs',
        }
        self.assertEqual(self.run_worker(), ['api_success.txt', 'orbs_buyer_failed.txt'])
        self.assertIn('Insufficient Orbs', self.save.call_args_list[1].args[1])

    def test_unconfirmed_purchase_is_not_saved_as_success(self):
        self.response.json.return_value['purchase']['status'] = 'unconfirmed'
        self.assertEqual(self.run_worker(), ['api_success.txt', 'orbs_buyer_failed.txt'])

    def test_skipped_purchase_is_not_saved_as_success(self):
        self.response.json.return_value['purchase']['status'] = 'skipped'
        self.assertEqual(self.run_worker(), ['api_success.txt', 'orbs_buyer_skipped.txt'])

    def test_already_owned_is_not_saved_as_new_purchase(self):
        self.response.json.return_value['purchase']['status'] = 'already_owned'
        self.assertEqual(self.run_worker(), ['api_success.txt', 'orbs_buyer_skipped.txt'])
        self.assertTrue(any('already owned' in call.args[1] for call in self.log.call_args_list))

    def test_claim_failure_is_not_saved_as_success(self):
        self.response.json.return_value = {'success': False, 'error': 'Claim rejected'}
        self.assertEqual(self.run_worker(), ['api_failed.txt'])

    def test_timeout_reports_unknown_outcome_without_retry(self):
        self.post.side_effect = orb.requests.exceptions.Timeout()
        result = orb.send_to_api_result('synthetic-test-token')
        self.assertFalse(result['success'])
        self.assertIn('360s', result['error'])
        self.assertIn('outcome unknown', result['error'])
        self.post.assert_called_once()

    def test_offline_server_drains_queue(self):
        self.post.side_effect = orb.requests.exceptions.ConnectionError()
        orb.TOKEN_QUEUE.put('synthetic-second-token')
        self.assertEqual(self.run_worker(), ['api_failed.txt'])
        self.assertTrue(orb.TOKEN_QUEUE.empty())
        self.post.assert_called_once()


class OrbsBuyerDisplayTests(unittest.TestCase):
    def config_rows(self, cfg):
        with patch.object(interface, 'load_config', return_value=cfg), \
             patch.object(interface, 'get_orb_token_count', return_value=0), \
             patch.object(interface, 'show_detail') as show:
            interface.screen_config()
        return '\n'.join(interface.theme.strip_ansi(row) for row in show.call_args.args[1])

    def test_config_shows_default_buyer_and_confirmation_requirement(self):
        rows = self.config_rows({})
        self.assertIn('ORBS BUYER', rows)
        self.assertIn('1342211853484429445', rows)
        self.assertIn('Purchases only after a confirmed Orbs claim.', rows)

    def test_config_shows_selected_sku(self):
        rows = self.config_rows({'orb_buyer': {'enabled': False, 'sku_id': 'sample-selected-sku'}})
        buyer_rows = rows.split('ORBS BUYER')[1].split('SERVER SETUP')[0]
        self.assertIn('OFF', buyer_rows)
        self.assertIn('sample-selected-sku', buyer_rows)

    def test_dashboard_fits_expected_width_and_height_with_buyer(self):
        lines = interface.render_dashboard({'orb_buyer': True}, columns=80, rows=25, motion=False)
        self.assertLessEqual(len(lines), 24)
        self.assertTrue(all(interface.theme.visible_width(line) < 80 for line in lines))
        self.assertIn('Orbs Buyer', '\n'.join(lines))


if __name__ == '__main__':
    unittest.main()
