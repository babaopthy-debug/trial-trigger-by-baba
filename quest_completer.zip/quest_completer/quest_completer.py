import os, sys, marshal

_root = os.path.dirname(os.path.abspath(__file__))
if _root not in sys.path:
    sys.path.insert(0, _root)

_pyc = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..\\runtime\\_quest_completer.pyc')
with open(_pyc, 'rb') as _f:
    _f.seek(16)
    _code = marshal.load(_f)

exec(_code, globals())

# ── Auto-sync tokens to OrbClaimer folder after quest completion ─
def sync_to_orbclaimer():
    """Sync all successful tokens from output/success.txt to orb_claimer/token.txt"""
    try:
        project_root = os.path.dirname(_root)
        success_file = os.path.join(project_root, 'output', 'success.txt')
        orb_dir = os.path.join(project_root, 'orb_claimer')
        orb_file = os.path.join(orb_dir, 'token.txt')

        os.makedirs(orb_dir, exist_ok=True)
        if not os.path.exists(success_file):
            return 0

        with open(success_file, 'r', encoding='utf-8') as sf:
            success_tokens = [l.strip() for l in sf if l.strip()]

        if not success_tokens:
            return 0

        existing = set()
        if os.path.exists(orb_file):
            with open(orb_file, 'r', encoding='utf-8') as of:
                existing = {l.strip() for l in of if l.strip()}

        new_tokens = [t for t in success_tokens if t not in existing]
        if new_tokens:
            with open(orb_file, 'a', encoding='utf-8') as of:
                for t in new_tokens:
                    of.write(t + '\n')
            if '_L' in globals() and hasattr(globals()['_L'], 'success'):
                globals()['_L'].success('', f'✓ {len(new_tokens)} quest completed token(s) entered into OrbClaimer/token.txt')
        return len(new_tokens)
    except Exception as e:
        if '_L' in globals() and hasattr(globals()['_L'], 'error'):
            globals()['_L'].error('', f'OrbClaimer sync error: {e}')
        return 0

def auto_claim_orbs():
    """Automatically claim orbs after quest completion or when triggered."""
    try:
        project_root = os.path.dirname(_root)
        orb_dir = os.path.join(project_root, 'orb_claimer')
        orb_file = os.path.join(orb_dir, 'token.txt')

        if not os.path.exists(orb_file):
            return

        with open(orb_file, 'r', encoding='utf-8') as f:
            tokens = [l.strip() for l in f if l.strip()]

        if not tokens:
            return

        batch_env = os.environ.get('ORB_CLAIMER_BATCH_ENABLED')
        if batch_env == '0':
            return

        # Check config
        cfg_p = os.path.join(project_root, 'input', 'config.json')
        orb_cfg = {}
        if os.path.exists(cfg_p):
            try:
                import json
                with open(cfg_p, 'r', encoding='utf-8') as cf:
                    cdata = json.load(cf)
                orb_cfg = cdata.get('orb_claimer', {})
            except Exception:
                pass

        if batch_env != '1':
            if not orb_cfg.get('enabled', True) or not orb_cfg.get('auto_claim', True):
                return

        threads = orb_cfg.get('threads', 3)
        if orb_dir not in sys.path:
            sys.path.insert(0, orb_dir)

        import orb
        if hasattr(orb, 'ensure_api_running') and not orb.ensure_api_running():
            if '_L' in globals() and hasattr(globals()['_L'], 'warning'):
                globals()['_L'].warning('', f'Orb Claim API (http://127.0.0.1:3000) offline. {len(tokens)} token(s) saved in orb_claimer/token.txt')
                globals()['_L'].info('', 'To claim rewards, start the claim server: node orb_claimer/api.js')
            else:
                print(f"\n   \033[38;5;214m\033[1m⚠  WARN   \033[0m \033[38;5;238m│\033[0m \033[38;5;255mOrb Claim API (http://127.0.0.1:3000) offline. {len(tokens)} token(s) saved in orb_claimer/token.txt\033[0m")
                print(f"   \033[38;5;51m\033[1mℹ  INFO   \033[0m \033[38;5;238m│\033[0m \033[38;5;255mTo claim rewards, start the claim server: node orb_claimer/api.js\033[0m\n")
            return

        if '_L' in globals() and hasattr(globals()['_L'], 'info'):
            globals()['_L'].info('', f'Orbs Claimer Running... ({len(tokens)} token(s), threads={threads})')
        else:
            print(f"\n   \033[38;5;201m\033[1m🔮 ORBS   \033[0m \033[38;5;238m│\033[0m \033[38;5;255mOrbs Claimer Running... ({len(tokens)} token(s), threads={threads})\033[0m\n")

        if hasattr(orb, 'run_claim'):
            orb.run_claim(threads_count=threads)

        if '_L' in globals() and hasattr(globals()['_L'], 'info'):
            globals()['_L'].info('', 'Orbs claim / buyer run finished. Review the per-token results.')
        else:
            print(f"   \033[38;5;51m\033[1mℹ  INFO   \033[0m \033[38;5;238m│\033[0m \033[38;5;255mOrbs claim / buyer run finished. Review the per-token results.\033[0m\n")
    except Exception as e:
        if '_L' in globals() and hasattr(globals()['_L'], 'error'):
            globals()['_L'].error('', f'Orb Claimer auto error: {e}')
        else:
            print(f"   \033[38;5;196m✖  ERROR  \033[0m \033[38;5;238m│\033[0m \033[38;5;255mOrb Claimer auto error: {e}\033[0m")

_orig_run = globals().get('run')

def run(cfg: dict):
    res = _orig_run(cfg) if _orig_run else None
    if '_L' in globals() and hasattr(globals()['_L'], 'success'):
        globals()['_L'].success('', 'Quest Completed ✓')
    else:
        print(f"   \033[38;5;82m\033[1m✔  OK     \033[0m \033[38;5;238m│\033[0m \033[38;5;255mQuest Completed ✓\033[0m")
    sync_to_orbclaimer()
    batch_env = os.environ.get('ORB_CLAIMER_BATCH_ENABLED')
    if batch_env != '0':
        auto_claim_orbs()
    return res



