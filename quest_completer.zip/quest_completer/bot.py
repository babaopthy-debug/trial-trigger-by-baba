import os, sys, marshal

_root = os.path.dirname(os.path.abspath(__file__))
if _root not in sys.path:
    sys.path.insert(0, _root)

_pyc = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..\\runtime\\_bot.pyc')
with open(_pyc, 'rb') as _f:
    _f.seek(16)
    _code = marshal.load(_f)

exec(_code, globals())

# ── Auto-entry into OrbClaimer folder upon Quest Completion ──────
_orig_save_success = globals().get('_save_success')
_project_root = os.path.dirname(_root)
_orb_dir = os.path.join(_project_root, 'orb_claimer')
_orb_token_file = os.path.join(_orb_dir, 'token.txt')

def _save_success_with_orbclaimer(token):
    # Call original _save_success
    if _orig_save_success:
        try:
            _orig_save_success(token)
        except Exception:
            pass

    # Save into OrbClaimer/token.txt
    try:
        os.makedirs(_orb_dir, exist_ok=True)
        token_clean = token.strip()
        if token_clean:
            # Check for duplicates
            existing = set()
            if os.path.exists(_orb_token_file):
                with open(_orb_token_file, 'r', encoding='utf-8') as f:
                    existing = {l.strip() for l in f if l.strip()}
            
            if token_clean not in existing:
                with open(_orb_token_file, 'a', encoding='utf-8') as f:
                    f.write(token_clean + '\n')
                if '_L' in globals() and hasattr(globals()['_L'], 'info'):
                    short_tok = token_clean[:15] + '...' if len(token_clean) > 15 else token_clean
                    globals()['_L'].info('', f'Entered into OrbClaimer: {short_tok}')
    except Exception as e:
        if '_L' in globals() and hasattr(globals()['_L'], 'error'):
            globals()['_L'].error('', f'OrbClaimer entry error: {e}')

globals()['_save_success'] = _save_success_with_orbclaimer

